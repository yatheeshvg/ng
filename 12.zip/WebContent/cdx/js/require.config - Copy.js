requirejs.config({
    baseUrl: "../../cdx/",
    waitSeconds: 200,
    paths: {
        backtotop: "components/backtotop/js/backtotop.min",
        bootstrap: "components/bootstrap/js/bootstrap.min",
        "ge-bootstrap": "components/ge-bootstrap/js/ge-bootstrap.min",
        brandkit: "components/brandkit/js/brandkit",
        "collapsible-list": "components/collapsible-list/js/collapsible-list",
        "font-awesome": "components/font-awesome",
        jquery: "components/jquery/jquery.min",
        "jquery.validate": "components/jquery/jquery.validate.min",
        "mds-navbar": "components/mds-navbar/js/mds-navbar.min",
        modernizr: "components/modernizr/modernizr.min",
        modules: "components/modules/js/modules",
        respond: "components/respond/respond.src",
        "responsive-emitter": "components/responsive-emitter/js/responsive-emitter.min",
        spin: "components/spin.js/spin.min",
        requirejs: "components/requirejs/require.min",
        "responsive-tables": "components/responsive-tables/js/responsive-tables",
        "jqueryui-sortable": "components/jqueryui-sortable-amd/js/jquery-ui-1.10.2.custom.min"
    },
    shim: {
    	"bootstrap":["jquery"],
        "jquery.validate": ["jquery"]
    }
});
