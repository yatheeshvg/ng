var opts = {
		  lines: 17, 
		  length: 17, 
		  width: 5, 
		  radius: 30, 
		  corners: 1, 
		  rotate: 0, 
		  direction: 1, 
		  color: '#000',
		  speed: 1.1, 
		  trail: 58, 
		  shadow: false, 
		  hwaccel: false, 
		  className: 'spinner', 
		  zIndex: 2e9, 
		  top: '50%', 
		  left: '50%'
		};
var spinner = null;
require(['jquery',
         'spin',
         'bootstrap',
         'mds-navbar',
         'backtotop'
         ], function($,Spinner){
	spinner=new Spinner(opts).spin();

	$(document).ready(function() {
		spin_start('body');
		$('.jobDetails').hide();
		loadPrimaryFilters();
		loadPositionDetails("ALL", "ALL","ALL");
		$('#select-bus').change(function() {
			spin_start('body');
			loadPositionDetails($('#select-bus').val(),
			$('#select-functn').val(),$('#select-country').val());
		});
		$('#select-functn').change(function() {
			spin_start('body');
			loadPositionDetails($('#select-bus').val(),
			$('#select-functn').val(),$('#select-country').val());
		});
		$('#select-country').change(function() {
			spin_start('body');
			loadPositionDetails($('#select-bus').val(),
			$('#select-functn').val(),$('#select-country').val());
		});
		$('#a1').on('click', function() {
			$('.jobDetails').hide();
			$('#a2').hide();
			$('#grtr').hide();
			$('#recentJobPostings').find('a').removeClass('active');
		});
		$("#openToolTip").on("click tap",function () {		
			$(".first-run-overlay").css("height",$(document).height()+"px");
			$(".first-run-overlay,.first-run-sprite,.first-run-text").show();
			return false;
		});
		$(".close-btn").on("click tap",function () {
			$(".first-run-overlay,.first-run-sprite,.first-run-text").hide();
			return false;
		});
	});
	$(document.body).on("click","#positionTypesList li h4 a",function(e) {
		spin_start('body');
		var filter = $(this).text();
		$('#positionTypesList').find('a').removeClass('active');
		$(this).addClass('active');
		$('#recentJobPostings ol').html();
		$('#a1').html();
		$('#a2').hide();
		$('#grtr').hide();
		$('#a1').html(filter);
		$('.jobDetails').hide();
		loadOverviewDetails(filter);
		loadAllVacancies(filter,$('#select-bus').val(),$('#select-country').val());
		return false;
	});

	$(document.body).on("click","#recentJobPostings li h4 a",function(e) {
		spin_start('body');
		var filter = $(this).attr("href");
		var overview = $(this).text();// alert(filter);
		$('#recentJobPostings').find('a').removeClass('active');
		$(this).addClass('active');
		$('#grtr').show();
		$('#a2').show();
		$('#a2').html(overview);
		loadVacancyDetails(filter);
		return false;
	});

});
function spin_start(target){
    spinner.spin($(target).get(0));
}
function spin_stop(target){
	spinner.stop($(target).get(0));
}
function getDocumentURL(){
	var url = document.URL;
	var result = new documentUrl();
	if (url.indexOf('#')>0) {
		result.url = url.substr(0, url.indexOf('#'));
		result.param = url.substr(url.indexOf('#'), url.length);
	} else {
		result.url = url;
		result.param = null;
	}
	return result;
}
function documentUrl(url, param) {
    this.url = url;
    this.param = param;
} 
function handleAjaxError(xhr, ajaxOptions, thrownError){
	if (xhr.status == 0 ){
		alert($("#sessionTimeOutMsg").val());
    	location.reload();    	
    } else {    	
    	alert($("#serverErrorMsg").val() + ": " + xhr.statusText);
    }
}
function replaceSpecialChars(str){
	   str = encodeURIComponent(str);
	   str = escape(str);
	   str=str.replace(/%27/g,'[$27]');
return str;
}
function loadPrimaryFilters() {
	$.ajax({
		url : getDocumentURL().url + "/jobfamilybusinesslist",
		dataType : "json",
		success : function(data) {
			var businessOptions = '<option value="ALL">All Businesses</option>';
			for (var i = 0; i < data.length; i++) {
				businessOptions = businessOptions + '<option value="'
						+ data[i].organizationName + '">' + data[i].organizationName
						+ '</option>';
			}
			$('#select-bus').html(businessOptions);
		}
	});
	$.ajax({
		url : getDocumentURL().url + "/jobfamilyfunctionlist",
		dataType : "json",
		success : function(data) {
			var functionOptions = '<option value="ALL">All Functions</option>';
			for (var i = 0; i < data.length; i++) {
				functionOptions = functionOptions + '<option value="'
						+ data[i].functionName + '">' + data[i].functionName
						+ '</option>';
			}
			$('#select-functn').html(functionOptions);
		}
	});
	$.ajax({
		url : getDocumentURL().url + "/jobfamilycountrylist",
		dataType : "json",
		success : function(data) {
			var countryOptions = '<option value="ALL">All Countries</option>';
			for (var i = 0; i < data.length; i++) {
				countryOptions = countryOptions + '<option value="'
						+ data[i].countryName + '">' + data[i].countryName
						+ '</option>';
			}
			$('#select-country').html(countryOptions);
		}
	});
}

function loadPositionDetails(business, functionn, country) {
	spin_start('body');
	$('#positionTypesList').html(""); $('#recentJobPostings ol').html("");
	$('.jobDetails').hide();
	$('#overviewQuals ul').html(""); $('#overviewResp ul').html("");
	$.ajax({
		url : getDocumentURL().url + "/futurepositionstypes?business=" + replaceSpecialChars(business)
				+ "&function=" + replaceSpecialChars(functionn) + "&country=" + replaceSpecialChars(country),
		dataType : "json",
		success : function(data) {
				$('#positionTypesList').html("");
				var jobPositions = "";
				if(data.length <= 3 || data[0] == undefined){
					$.ajax({
						url : getDocumentURL().url + "/jobfamilypositions?business=" + replaceSpecialChars(business) + "&function=" + replaceSpecialChars(functionn) + "&country=" + replaceSpecialChars(country),
						dataType : "json",
						success : function(data) {
							for (var i = 0; i < data.length; i++) {
								jobPositions = jobPositions
									+ '<li class="heading"><h4><a href="#">'
									+ data[i].jobFamily + '</a><span>' + data[i].percentageOfTotalJobFamilies
									+ '%</span></h4></li>';
							}
							$('#positionTypesList').html(jobPositions);
						}
					});
				}else{
				for (var i = 0; i < data.length; i++) {
				jobPositions = jobPositions
						+ '<li class="heading"><h4><a href="#">'
						+ data[i].positionType + '</a><span>' + data[i].percentageOfTotalPositionTypes
						+ '%</span></h4></li>';
				}
				$('#positionTypesList').html(jobPositions);
				}
		},
		error : function(xhr, ajaxOptions, thrownError) {
			handleAjaxError(xhr, ajaxOptions, thrownError)
		},
		complete: function(){
			spin_stop('body');
		}
	});
}

function loadAllVacancies(filtervalue,business,country) {
	spin_start('body');
	$('#recentJobPostings ol').html("");
	$.ajax({
		url : getDocumentURL().url + "/recentjobs?jobName=" + replaceSpecialChars(filtervalue),
		dataType : "json",
		success : function(data) {
			if (data.length == 0 || data[0] == undefined) {
				//$('#recentJobPostings ol').html("No Recent vacancies found!");
				$.ajax({
					url : getDocumentURL().url + "/jobfamilyvacancies?jobfamily=" + replaceSpecialChars(filtervalue)+ "&business=" + replaceSpecialChars(business) + "&country=" + replaceSpecialChars(country),
					dataType : "json",
					success : function(data) {
						if (data[0] == undefined) {
							$('#recentJobPostings ol').html("No Recent vacancies found!");
						}else{
							var jobPostings = "";
							for (var i = 0; i < data.length; i++) {
								jobPostings = jobPostings
										+ '<li class = "heading"><h4><a href="'
										+ data[i].vacNumber + '">' + data[i].title
										+ '</a></h4></li>';
							}
							$('#recentJobPostings ol').html(jobPostings);
						}
					}
				});
			} else {
				var jobPostings = "";
				for (var i = 0; i < data.length; i++) {
					jobPostings = jobPostings
							+ '<li class = "heading"><h4><a href="'
							+ data[i].vacancyNumber + '">' + data[i].title
							+ '</a></h4></li>';
				}
				$('#recentJobPostings ol').html(jobPostings);
			}
		},
		complete: function(){
			spin_stop('body');
		}
	});
}

function loadVacancyDetails(filtervalue) {
	spin_start('body');
	$.ajax({
		url : getDocumentURL().url + "/jobdetail?vacancyNumber=" + replaceSpecialChars(filtervalue),
		dataType : "json",
		success : function(data) {
			$('.jobDetails').show();
			// Qualifications
			$('#qualifications').attr('style', 'padding-left:25px');
			$('#qualifications').html(data.requiredQualification);
			// Characteristics
			$('#characteristics').attr('style', 'padding-left:25px');
			$('#characteristics').html(data.desiredCharacteristics);
			// Responsibilities
			$('#responsibilities').attr('style', 'padding-left:25px');
			$('#responsibilities').html(data.responsibilities);
		},
		complete: function(){
			spin_stop('body');
		}
	});
}

function loadOverviewDetails(filtervalue) {
	spin_start('body');
	$('#overviewQuals ul').html("");
	$('#overviewResp ul').html("");
	$.ajax({
		url : getDocumentURL().url + "/jobtypelibrary?jobType="+replaceSpecialChars(filtervalue),
		dataType : "json",
		success : function(data) {
			$('#ovrviewTitle').show();
			$('#overviewQuals ul').html(data.requiredQualification);
			$('#overviewResp ul').html(data.responsibilites);
		}
	});
}

function loadfuturePostings() {
	spin_start('body');
	$.ajax({
		url : getDocumentURL().url + "/possiblejobtypes",
		dataType : "json",
		success : function(data) {
			('').html(data.jobType);
		},
		complete: function(){
			spin_stop('body');
		}
	});
}