var activeTabId = "#tab_user_information";
var activeSubTab = "";
var deepLinkParam = "";
var containerInit = "";
var profilePhoto=null;
var assignmentLoaded = true;
var assignmentHistoryLoaded = false;
var serviceDatesLoaded = false;
var myClientsLoaded = false;
var myReportsLoaded = true;
var contactsDemographicsLoaded = false;
var employeeHistoryLoaded = false;
var educationLoaded = false;
var performanceLoaded = false;
var compensationLoaded = false;
var typeaheadSelect = null;
var updateLink = "";
var spinner = null;
var trainingSelected = "";
var trainingSelectedId = "";
var ERROR_MSG = "Internal error";
var toDelTraining = false;
var hasDirectReports = false;
var hasDottedLineDirectReports = false;
var hasContingentWorkerReports = false;
var stk_options_total = "";
var rsu_grant_history_total = "";
var counter = 0;
var opts = {
		  lines: 17, 
		  length: 17, 
		  width: 5, 
		  radius: 30, 
		  corners: 1, 
		  rotate: 0, 
		  direction: 1, 
		  color: '#000',
		  speed: 1.1, 
		  trail: 58, 
		  shadow: false, 
		  hwaccel: false, 
		  className: 'spinner', 
		  zIndex: 2e9, 
		  top: '50%', 
		  left: '50%'
		};
var spinner = null;
require(['jquery', 
         'spin',
         'bootstrap',
         'mds-navbar',
         'backtotop'
         ], function($,Spinner){
	profilePhoto=$('#photoURL').val();
	spinner=new Spinner(opts).spin();
	
	$(document).ready(function(){
		
		$('body').show();
		$('body').append('<div class="sidr-overlay push-menu"></div>');
		if($('#checkSensitiveData').val()=='true'){
			$('#security-modal').modal('show');
			$(".security-modal").on('click',function(){	
				var buttonVal = $($(this).attr("href")).val();
				window.location.href=getDocumentURL().url+"/email_reportissue?flag="+buttonVal;
				return false;
			});	
		}
		if($('#showInfoPopup').val()=='true'){
			$('#infoPopup-modal').modal('show');
			$(".infoPopup-modal").on('click',function(){	
				var buttonVal = $($(this).attr("href")).val();
				$.post( getDocumentURL().url + '/info_popup', {flag: buttonVal}, function(){$('#infoPopup-modal').modal('hide');});
				return false;
			});	
		}		
		$("#div_photo").html('<img id="photo" src="'+profilePhoto+$('#employeeSSO').val()+'.jpg" onerror="this.style.visibility=&#39;hidden&#39;; showNoPhoto(&#39;div_photo&#39;,&#39;div_photo&#39;);"/>');

	    //$('#responsive-menu-button').sidr({side: 'right'});

	    var isTouchDevice = 'ontouchstart' in document.documentElement;
	    if (!isTouchDevice) {
	      $('[rel=tooltip]').tooltip({ container: 'body' });
	    }

	    $('[rel=popover]').popover({ trigger: 'click' }).on('click', function(e) {
	      e.preventDefault();
	    });

	    $('.navbar').navbar();
		
	    // Disable zoom only on start for iOS.  Zooming still works post load -- still don't like this
	    if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i)) {
	      var viewportmeta = document.querySelector('meta[name="viewport"]');
	      if (viewportmeta) {
	        viewportmeta.content = 'width=device-width, minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0';
	        document.body.addEventListener('gesturestart', function () {
	          viewportmeta.content = 'width=device-width, minimum-scale=0.25, maximum-scale=1.6';
	        }, false);
	      }
	    }
		
    	$('#responsive-menu-button').on('click tap',function(){	
    	  if(!( $( '#responsive-menu-button' ).hasClass('togglemenu'))){
    		  sidr_open();
    	  }else{
    		  sidr_close();
    	  }
    	});
		
    	sidrCollapse();
    	tableOpenClose();
    	$(window).on('resize', function (event) {
    		sidrCollapse();
    	});
		
		// Exit form function If it is a error page
		if($('#error_page').length>0){
			return;
		}
		
		
		deepLinkParam = $('#deepLinkParam').val();
		if(deepLinkParam=="" || deepLinkParam==null || deepLinkParam==undefined){
			containerInit = getDocumentURL().param;
		}
		else{
			if(deepLinkParam=="tooltip"){
				containerInit = getDocumentURL().param;
				//tooltip code goes here
			}
			else if(deepLinkParam=="assignment" || deepLinkParam=="current_assignment" || deepLinkParam=="current_information"){
				containerInit="#tab_user_information";
			}
			else if(deepLinkParam=="personal_data" || deepLinkParam=="demographics" || deepLinkParam=="contacts_demographics"){
				containerInit="#tab_contacts_demographics";
			}
			else if(deepLinkParam=="assignment_history" || deepLinkParam=="ohr_history"){
				containerInit="#tab_work_history";
				activeSubTab="#tab_ohr_history";
			}
			else if(deepLinkParam=="internal_resume" || deepLinkParam=="employment_history" || deepLinkParam=="work_history"){
				containerInit="#tab_work_history";
				activeSubTab="#tab_employment_history";
			}
			else if(deepLinkParam=="education" || deepLinkParam=="training" || deepLinkParam=="education_training"){
				containerInit="#tab_education_training";
			}			
			else if(deepLinkParam=="appraisal" || deepLinkParam=="performance"){
				containerInit="#tab_appraisal";
			}
			else if(deepLinkParam=="compensation"){
				containerInit="#tab_compensation";
			}
			else if(deepLinkParam=="my_hr_clients" || deepLinkParam=="my_client_managers"){
				containerInit="#tab_hr_client_managers";
			}
			else{
				containerInit="#tab_user_information";
			}
		}
		activeTabId=containerInit;
		if (containerInit == null || containerInit == undefined){
			initContainer("#tab_user_information");
		} else {
			try {
				initContainer(containerInit);
			}
			catch(err){
				initContainer("#tab_user_information");
			}
		}
		
		$("#container ul.nav li").on('click tap',function(){	
			sidr_close();
			var activeContainer = $(this).find("a").attr("href");
			initContainer(activeContainer);
			return false;
		});	
		
		if($('#contingentView').val()){
			$("#div_photoSup").html('<img class="photo1" src="'+profilePhoto+validnull($('.a_manager_sso').attr('href'))+'.jpg" onerror="this.style.visibility=&#39;hidden&#39;; showNoPhoto(&#39;div_photoSup&#39;,&#39;div_photo2&#39;);"/>');
			if($('#sponsorView').val()=="true"){
				if($('#workRequestStatus').text()=='Expired'){
					$('#workRequestStatus').addClass('red');
				}
				var days=daysLeft($("#ssoEndDate").val());
				if(days>30){
					$("#ssoStatus").html("");	
				}else if(days<=30 && days>0){
					$("#ssoStatus").html("(Expires in "+days+" days)");
				}else if(days<=0){
					$("#ssoStatus").html("(SSO has expired)");
				}else{
					$("#ssoStatus").html("");
				}
			}
		}
		
		typeaheadSearch();
		
		$(".helpVertical").on("click tap",function () {		
			//$('div').scrollTop(0);
			$(".first-run-overlay").css("height",$(document).height()+"px");
			$(".first-run-overlay,.first-run-sprite").show();
			/*$(".first-run-sprite.messy-dashboard1").show();
			$(".first-run-sprite.messy-dashboard2").show();
			$(".first-run-sprite.messy-dashboard3").show();
			$(".first-run-sprite.messy-dashboard4").show();
			$(".first-run-sprite.messy-dashboard5").show();
			$(".first-run-sprite.messy-dashboard6").show();
			$(".first-run-sprite.messy-dashboard7").show();*/
			return false;
		});

		$(".close-btn").on("click tap",function () {
			$(".first-run-overlay,.first-run-sprite").hide();
			return false;
		});
		
		$("#tab_nav_work_history ul.nav li").on('click tap',function(){
			activeSubTab = $(this).find("a").attr("href");
			populateWorkHistory(activeSubTab);
			return false;
		});
		
		$("#stockOptionsValuationForm").submit(function(){
			$("#stockOptionsValuationForm input[type='button']").click();
			return false;
		});
		
		  $('.accordion .collapse')
		    .on('show hide load', toggleAccordionToggle)
		    .trigger('load');
				
		//Stock Options Valuation
		$("#stockOptionsValuationForm input[type='button']").on("click",function(){
			if($("#stockOptionsValuationForm").valid()){
				var stockValuation = $("#stockOptionsValuationForm input[name='field']").val();
				
				var stockOtionsRows = $("#table_stock_option tr.stockVal");
				var totalRSU = $("#restrctd_total_rsus_unvested").text().replace(',','');

				if(stockValuation > 0 && stockValuation != '' && stockValuation != undefined){
					
					var totalValueTotal = 0;
					var totalValueVested = 0;
					var totalValueUnvested = 0;
					for(var cc = 0; cc < stockOtionsRows.length; cc++){
						var finalPrice = getCurrentStockPrice(stockValuation, getTdValue(stockOtionsRows[cc], 1) );
						var finalTotal = getTotal(finalPrice, getTdValue(stockOtionsRows[cc], 4));
						var finalVested = getVestedUnvested(finalPrice, getTdValue(stockOtionsRows[cc], 5));
						var finalUnvested = getVestedUnvested(finalPrice, getTdValue(stockOtionsRows[cc], 6));
						
						//set Total
						totalValueTotal +=  finalTotal;
						totalValueVested += finalVested;
						totalValueUnvested += finalUnvested;
						
					}	
						
					//Set Totals
					$("#long_term_total_value_total").html(addCommas( roundNumber(totalValueTotal,2) ) );
					$("#long_term_total_value_vested").html(addCommas( roundNumber(totalValueVested,2) ) );
					$("#long_term_total_value_unvested").html(addCommas( roundNumber(totalValueUnvested,2) ) );
					
					$("#restrctd_total_value_unvested").html(addCommas( roundNumber(totalRSU*stockValuation,2) ));
					
					
					stk_options_total='&stk_opt_outstanding_total='+$('#long_term_total_value_total').text()
									+'&stk_opt_vested_total='+$('#long_term_total_value_vested').text()
									+'&stk_opt_unvested_total='+$('#long_term_total_value_unvested').text();
					
					rsu_grant_history_total='&rsu_grant_hist_total='+$('#restrctd_total_value_unvested').text();
					
				}
			}
		});
		$("#pdf-button").on('click',function(){
			lazyLoadJqueryUISortable();
			$('#pdfPopup-modal').modal('show');
			sidr_close();
			return false;
		});	
		$(".pdfPopup-modal").on('click',function(){
			$('#pdfPopup-modal').modal('hide');
			var cnt = $("input[name='columns']:checked").length;
			if (cnt > 0){
				var sortorder="";
				$('#sortable').children().each( function( index ){
					sortorder+= "&sortorder="+$(this).attr('data-value');
				});
				window.open(getDocumentURL().url+"/pdf_preview?"+$('#pdfDownload').serialize()+sortorder+stk_options_total+rsu_grant_history_total);		
			}
			return false;
		});


			
		$("#viewAllReport").on('click' ,function(){
			populateMyReports();
		});

		$('.exportExcel').on('click' ,function(){
            window.location.href= getDocumentURL().url+"/excel_myreports";
			//$( this ).dialog( "close" );
			return false;
		});	
		
		$(".transactions").popover({
			trigger: 'click',
			container: 'body',
			html:true,
			title:'Alert',
			content:function(){
				if($(this).hasClass("dialogtransaction")){
					return $("#dialog2").html();
				}else if($(this).hasClass("dialogtransactioni")){
					return $("#dialog2i").html();
				}
			}
		}).on("shown.bs.popover",function(){
						updateLink=$(this).attr("href");
					
						$(".updateBtn").on("click",function(){	
							window.open(updateLink);
							$('[rel="dialog-popover"]').popover('hide');
						});
				
			});
		
	    $(document.body).on("click tap","#search-btn",function(e){
	    	openTypeAheadSearchResults();
			e.preventDefault();
		});
		
		$(document.body).on("click tap","#searchResultsBtn",function(e){
			openSearchResults();
			e.preventDefault();
		});
		
		//Advanced Search 
		$(document.body).on("click tap","#advancedSearchBtn",function(e){
			    sidr_close();
			    spin_start("body");
			    window.location.href="../search";
			    e.preventDefault();
		   });
			
			
			$(".update,.updateResume").popover({
				trigger: 'click',
				container: 'body',
				html:true,
				title:'Alert',
				content:function(){
					if($(this).hasClass("dialog1")){
						return $("#dialog1").html();
					}else if($(this).hasClass("dialog2")){
						return $("#dialog2").html();
					}else if($(this).hasClass("dialog3")){
						return $("#dialog3").html();
					}else if($(this).hasClass("dialog4")){
						return $("#dialog4").html();
					}			        
			    }
			}).on("shown.bs.popover",function(){
				updateLink=$(this).attr("href");
				$(".updateBtn").on("click",function(){				
					window.open(updateLink);
					$('[rel="dialog-popover"]').popover('hide');
				});
			});	
			
		    $('[rel="dialog-popover"]').on('click tap', function (event) {
		        event.preventDefault();
		        $('[rel="dialog-popover"]').not(this).popover('hide');
		      });
			
		    $(document).on('click tap', function (event) {
		        if( ( $(event.target).parents('.popover').length === 0 &&
		            $(event.target).attr('rel') !== 'dialog-popover') ||
		            $(event.target).parents('.close').length > 0 ||
		            $(event.target).hasClass('close')) {
		          $('[rel="dialog-popover"]').popover('hide');
		        }
		    });

	        $(window).on('resize', function (event) {
	            $('[rel="dialog-popover"]').popover('hide');
	            $(".first-run-overlay").css("height",$(document).height()+"px");
	        });
	        
	    	$(document.body).on("click","#moreElement",function(e){
	    		openTypeAheadSearchResults();
	    		e.preventDefault();
	    	});	
	        
	        
			$(".optinShare").popover({
				trigger: 'click',
				container: 'body',
				html:true,
				content:function(){
					if($(this).attr("id")=="optin_empHistory"){
						if($(this).hasClass("dialog5")){
							return $("#dialog5").html();
						}else if($(this).hasClass("dialog6")){
							return $("#dialog6").html();
						}
					}else if($(this).attr("id")=="optin_education"){
						if($(this).hasClass("dialog7")){
							return $("#dialog7").html();
						}else if($(this).hasClass("dialog8")){
							return $("#dialog8").html();
						}
					}else if($(this).hasClass("optin_training_select")){
						if($(this).hasClass("dialog9")){
							return $("#dialog9").html();
							toDelTraining=true;
						}else if($(this).hasClass("dialog10")){
							return $("#dialog10").html();
							toDelTraining=false;
						}
						trainingSelected=$(this).parent().find('input').val();		
					}		        
			    }
			}).on("shown.bs.popover",function(){
				//updateLink=$(this).attr("href");
				$(".optinShareBtnEmp").on("click",function(){					
					$('[rel="dialog-popover"]').popover('hide');
					if($('#optinEmpHistory').val()=='Y'){
						$('#optin_empHistory').addClass("dialog5");
						$('#optin_empHistory').removeClass("btn-primary");
						$('#optin_empHistory').removeClass("dialog6");
						$('#optin_empHistory').text("Not Shared");
						$('#optinEmpHistory').val("N")
					}else if($('#optinEmpHistory').val()=='N'){
						$('#optin_empHistory').addClass("dialog6");
						$('#optin_empHistory').addClass("btn-primary");
						$('#optin_empHistory').removeClass("dialog5");
						$('#optin_empHistory').text("Shared");
						$('#optinEmpHistory').val("Y")						
					}
					setOptinSharing("EMP_HISTORY",$('#optinEmpHistory').val());
				});
				$(".optinShareBtnEdu").on("click",function(){					
					$('[rel="dialog-popover"]').popover('hide');
					if($('#optinEducation').val()=='Y'){
						$('#optin_education').addClass("dialog7");
						$('#optin_education').removeClass("btn-primary");
						$('#optin_education').removeClass("dialog8");
						$('#optin_education').text("Not Shared");
						$('#optinEducation').val("N")
					}else if($('#optinEducation').val()=='N'){
						$('#optin_education').addClass("dialog8");
						$('#optin_education').addClass("btn-primary");
						$('#optin_education').removeClass("dialog7");
						$('#optin_education').text("Shared");
						$('#optinEducation').val("Y")						
					}
					setOptinSharing("EDUCATION",$('#optinEducation').val());
				});
				$(".optinShareBtnTrn").on("click",function(){									
					$('[rel="dialog-popover"]').popover('hide');
					if($('#optinTraining').val()=='Y'){
						$('#optin_training').addClass("dialog9");
						$('#optin_training').removeClass("btn-primary");
						$('#optin_training').removeClass("dialog10");
						$('#optin_training').text("Not Shared");
						$('#optinTraining').val("N")
					}else if($('#optinTraining').val()=='N'){
						$('#optin_training').addClass("dialog10");
						$('#optin_training').addClass("btn-primary");
						$('#optin_training').removeClass("dialog9");
						$('#optin_training').text("Shared");
						$('#optinTraining').val("Y")						
					}
					setOptinTrainingSharing();
				});
				$(".optinCancelBtn").on("click",function(){				
					$('[rel="dialog-popover"]').popover('hide');
				});
			});	
		});
	

});

function spin_start(target){
    spinner.spin($(target).get(0));
}
function spin_stop(target){
	spinner.stop($(target).get(0));
}
function handleAjaxError(xhr, ajaxOptions, thrownError){
	if (xhr.status == 0 ){
		//alert($("#sessionTimeOutMsg").val());
    	location.reload();    	
    } else {    	
    	alert($("#serverErrorMsg").val() + ": " + xhr.statusText);
    }
}
function showNoPhoto(divName, className){ 
	$('#'+divName).text('No Photo');
	$('#'+divName).addClass(className);
}
function sidr_open(){
	$('#responsive-menu-button').addClass('togglemenu');
	$('body').addClass('sidr-open');
	$('.sidr').addClass('right');
	$('.sidr').show();
	$('.sidr').scrollTop(0);
}
function sidr_close(){
	if( $('#responsive-menu-button' ).hasClass('togglemenu')){
		$('#responsive-menu-button').removeClass('togglemenu');
		$('body').removeClass('sidr-open');
		$('.sidr').removeClass('right');
		$('.sidr').hide();
	}
}
function createHref(url,label){
	var link = "";
	if(label != null && label != '' ){
		link = "<a href='" +url+ "'>" + label + "</a>";
	}
	return link;
}
function getDocumentURL(){
	var url = document.URL;
	var result = new documentUrl();
	if (url.indexOf('#')>0) {
		result.url = url.substr(0, url.indexOf('#'));
		result.param = url.substr(url.indexOf('#'), url.length);
	} else {
		result.url = url;
		result.param = null;
	}
	return result;
}
function documentUrl(url, param) {
    this.url = url;
    this.param = param;
} 
function validnull (value){
	if (value != null){
		return value;
	} else {
		return '';
	}
}
function addCommas(nStr)
{
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}
function removeNumFormat(num){
	return parseFloat( new String(num).replace(",","") );
}
function roundNumber(num, decimalPositions){
	if(!isNaN(num)){
		num = parseFloat(num).toFixed(decimalPositions);
	}	
	return num;
}
function getTdValue(rowElement, columnNumber){
	return getStockTd(rowElement, columnNumber).text();
}
function getStockTd(rowElement, columnNumber){
	return $(rowElement).find("td:eq("+columnNumber+")");
}
function getCurrentStockPrice(stockValuation, stockPrice){
	return Math.max(stockValuation - removeNumFormat( stockPrice ), 0);
}
function getTotal(price, total){
	return price * removeNumFormat( total );
}
function getVestedUnvested(price, vestedUnvested){
	return price * removeNumFormat( vestedUnvested );
}
function daysLeft(indate)
{
    var d = new Date();
    var mm = d.getMonth()+1;
    var dd = d.getDate();
    var yyyy= d.getFullYear();

    var sysdate = yyyy + '-' + mm + '-' + dd;
    return daydiff(parseDate(sysdate), parseDate(indate));
}
function parseDate(str)
{
    var mdy = str.split('-');
    return new Date(mdy[0], mdy[1]-1, mdy[2]);
}

function daydiff(first, second) {
    return roundNumber((second-first)/(1000*60*60*24),0);
}
function toggleAccordionToggle(event) {
    var $target = $(event.target);
    var $toggle = $target.parent('.accordion-group').find('.accordion-toggle');
    if (event.type === 'show' || (event.type === 'load' && $target.hasClass('in'))) {
      $toggle.addClass('in');
    } else if (event.type === 'hide') {
      $toggle.removeClass('in');
    }
  }
function initContainer(activeTab) {	
	
	$(".tab_content").hide();
	$("#container ul.nav li").removeClass("active");
	
	$(activeTab).show(); 
	
	if(activeTab == "#tab_user_information"){
	$("#container ul.nav li a[href='#tab_user_information']").parent().addClass("active").show();
		if($('#contingentView').val()=='false'){
			populateAssignment();
		}
	}else if(activeTab == "#tab_contacts_demographics"){
		$("#container ul.nav li a[href='#tab_contacts_demographics']").parent().addClass("active").show();
		populateContactsDemographics();
	}else if(activeTab == "#tab_work_history"){
		$("#container ul.nav li a[href='#tab_work_history']").parent().addClass("active").show();
		if(activeSubTab=="#tab_ohr_history"|| activeSubTab=="#tab_employment_history"){
			populateWorkHistory(activeSubTab);
		}else{
			populateEmployeeHistory();
		}
	}else if(activeTab == "#tab_education_training"){
		$("#container ul.nav li a[href='#tab_education_training']").parent().addClass("active").show();
		populateEducation(); 
	}else if(activeTab == "#tab_appraisal"){
		$("#container ul.nav li a[href='#tab_appraisal']").parent().addClass("active").show();
		populatePerformance();
	}else if(activeTab == "#tab_compensation"){
		$("#container ul.nav li a[href='#tab_compensation']").parent().addClass("active").show();
		populateCompensation();
	}else if(activeTab == "#tab_hr_client_managers"){
		$("#container ul.nav li a[href='#tab_hr_client_managers']").parent().addClass("active").show();
		populateMyClients();
	}
	activeTabId=activeTab;
}
function populateAssignment(){
	if (assignmentLoaded == false){
		assignmentLoaded = true;
		
		//$("#tab_curr_assignment tr").show();// Show all <tr> that were hided because <td>
		// Block Work area while data is populated
		spin_start('#tab_user_information');
		// load assignment
		$.ajax({
			//url: getDocumentURL().url + '/json_assignment',
			url: '../../data/213004520/json_assignment.json',
			success: function(data) {
				if(data!=null){				
					if(data.success){
						
						var workAssgmnt = data.workAssignment;
						var dottedLineMgr = data.dottedLineManager;
						var workAssgmntRestrd = data.workAssignmentRestrd;
						var localBand = data.localBand;						
						var costCenter = data.costCenter;
						var headCountCostCenter = data.headCountCostCenter;
						
						if (workAssgmnt != null && workAssgmnt.granted == true){ 
							$('#industrySegment').text(workAssgmnt.ifg);
							$('#bussinesSegment').text(workAssgmnt.businessSegment);
							$('#subBusiness').text(validnull(workAssgmnt.subBusiness));
							$('#org').text(workAssgmnt.org);							
							$('#employeeType').text(workAssgmnt.employeeType);
						    $('#jobFunction').text(workAssgmnt.jobFunction);
						    $('#jobFamily').text(validnull(workAssgmnt.jobFamily));						    
						    $('#positionTitle').text(workAssgmnt.positionTitle);
						    $('#manager').html(createHref(workAssgmnt.manager, validnull(workAssgmnt.managerName)));
						    $('#hrManager').html(createHref(workAssgmnt.hrManager, validnull(workAssgmnt.hrManagerName)));
						    $('#legalEntity').text(workAssgmnt.legalEntity);
						} else {
							
							$('#org').parent().hide();
							$('#employeeType').parent().hide();
						    $('#jobFunction').parent().hide();
						    $('#jobFamily').parent().hide();						    
						    $('#positionTitle').parent().hide();
						    $('#manager').parent().hide();
						    $('#hrManager').parent().hide();
						    $('#legalEntity').parent().hide();
						}
						
						if (dottedLineMgr != null && dottedLineMgr.granted == true){
							$('#dottedLineManager').html( createHref(dottedLineMgr.dottedLineManager, validnull(dottedLineMgr.dottedLineManagerName)));
						}
						
						if (workAssgmntRestrd != null && workAssgmntRestrd.granted == true){
							//$('#monthsInPosition').text(workAssgmntRestrd.monthsInPosition);
							$('#jobType').text(workAssgmntRestrd.jobType);
							$('#gmeInfoHomeCountry').text(validnull(workAssgmntRestrd.gmeInfoHomeCountry));
							$('#band').text(workAssgmntRestrd.band);
							$('#payrollName').text(validnull(workAssgmntRestrd.payrollName));
							$('#payrollProcesor').text(validnull(workAssgmntRestrd.payrollProcessorCode));
							//$('#monthsInJob').text(workAssgmntRestrd.monthsInJob);
							 
						} else {
							$('#band').parent().hide();
							$('#gmeInfoHomeCountry').parent().hide();
							//$('#monthsInPosition').parent().hide();
							$('#jobType').parent().hide();
							$('#payrollName').parent().hide();
							$('#payrollProcesor').parent().hide();
							//$('#monthsInJob').parent().hide();
							
						}
						
						
						if(localBand != null && localBand.granted == true){
							$('#localBand').text(localBand.localBand);
						}else{
							 
							 $('#localBand').parent().hide();
						}	
						

						if(costCenter != null && costCenter.granted == true){
							$('#costCenter').text(validnull(costCenter.costCenter));
						    $('#adn').text(costCenter.adn);
						    $('#buc').text(costCenter.buc);
						}else{
							$('#costCenter').parent().hide();
						    $('#adn').parent().hide();
						    $('#buc').parent().hide();
						}
						
						if(headCountCostCenter != null && headCountCostCenter.granted == true){
						    $('#headcountCostCenter').text(validnull(headCountCostCenter.headcountCostCenterCode));
						}else{
						    $('#headcountCostCenter').parent().hide();
						}
						
						//Supervisor Hierarchy
						if(data.superHierarchyPerInfoList != null && !data.superHierarchyPerInfoList.empty && data.superHierarchyPerInfoList.granted){						    
						    var length = data.superHierarchyPerInfoList.list.length;

						    var tableHtml = '';
				    		tableHtml += '<div id="div_photo0" >';
				    		tableHtml += '<img class="photo1" src="'+profilePhoto+validnull(data.superHierarchyPerInfoList.list[0].sso)+'.jpg" onerror="this.style.visibility=&#39;hidden&#39;; showNoPhoto(&#39;div_photo0&#39;,&#39;div_photo2&#39;);"/>';
				    		tableHtml += '</div>';
				    		$("#leadershipManager").html(tableHtml);
				    		tableHtml = '';
				    		tableHtml += '<div align="center" class="leader-name"><a href="'+validnull(data.superHierarchyPerInfoList.list[0].sso)+'">' + validnull(data.superHierarchyPerInfoList.list[0].firstName) + '<br/>' + validnull(data.superHierarchyPerInfoList.list[0].lastName) + '</a></div></div>';
				    		$("#leadershipManagerName").html(tableHtml);						    
				    		if(length>1){
							    for (var i = 1; i < length; i++) {	
						    		tableHtml = '' ;
						    		tableHtml += '<div id="div_photo'+i+'" >';
						    		tableHtml += '<img class="photo1" src="'+profilePhoto+validnull(data.superHierarchyPerInfoList.list[i].sso)+'.jpg" onerror="this.style.visibility=&#39;hidden&#39;; showNoPhoto(&#39;div_photo'+i+'&#39;,&#39;div_photo2&#39;);"/>';
						    		tableHtml += '</div>';
						    		$("#leadershipHier"+i).html(tableHtml);
						    		tableHtml = '';
						    		tableHtml += '<div align="center" class="leader-name"><a href="'+validnull(data.superHierarchyPerInfoList.list[i].sso)+'">' + validnull(data.superHierarchyPerInfoList.list[i].firstName) + '<br/>' + validnull(data.superHierarchyPerInfoList.list[i].lastName) + '</a></div>';
						    		$("#leadershipHier"+i+"Name").html(tableHtml);
							    }
				    		}else{
				    			$("#leadershipOrgHier").hide();
				    		}
				    		$("#div_leadership").show();				    		
						}
						else{						
							$("#div_leadership").hide();
						}
						
						//					
					    //direct reports 
					    if(data.directReptsAssignmtList != null  && 
					    			!data.directReptsAssignmtList.empty &&
					    				data.directReptsAssignmtList.granted){					    	
						    var listHtml = '' ;						    
						    var length = data.directReptsAssignmtList.list.length;
						    hasDirectReports = true;
						    
						    for (var i = 0; i < length; i++) {						    	
						    	listHtml +=    '<tr>';
						    	if( data.directReptsAssignmtList.granted){
						    		listHtml +='<td><a href="'+validnull(data.directReptsAssignmtList.list[i].sso)+'">'+validnull(data.directReptsAssignmtList.list[i].lastName) +', '+ validnull(data.directReptsAssignmtList.list[i].firstName) + '</a></td>';
						    		listHtml +='<td>'+validnull(data.directReptsAssignmtList.list[i].sso)+'</td>';
							    	listHtml +='<td>'+validnull(data.directReptsAssignmtList.list[i].positionTitle)+'</td>';					    	
						    	}
						    	listHtml +='</tr>';
						    }						    
						    $("#directReportsList tbody").html(listHtml);
					    }else{
							$("#directReportsListDiv").show();
							$("#directReportsListDiv .accordion-heading a").addClass("in");
					    	$("#directReportsListDiv .accordion-body").addClass("in");
					    	$("#directReportsList").parent().html("No Direct Reports");
					    	$("#directReportsList").hide();
					    	$(".reports-list").css("height","150px");
					    }
					    

					    //
					   //dotted line direct reports 
					    if(data.dottedLineDirectReptsList != null  && !data.dottedLineDirectReptsList.empty  && data.dottedLineDirectReptsList.granted){
				    	
					    var listHtml = '' ;						    
					    var length = data.dottedLineDirectReptsList.list.length;
					    hasDottedLineDirectReports = true;
					    
					    for (var i = 0; i < length; i++) {
					    	
					    	if( data.dottedLineDirectReptsList.granted){
						    	listHtml +=    '<tr>';
						    	if( data.dottedLineDirectReptsList.granted){
						    		listHtml +='<td><a href="'+validnull(data.dottedLineDirectReptsList.list[i].sso)+'">'+validnull(data.dottedLineDirectReptsList.list[i].lastName) +', '+ validnull(data.dottedLineDirectReptsList.list[i].firstName) + '</a></td>';
						    		listHtml +='<td>'+validnull(data.dottedLineDirectReptsList.list[i].sso)+'</td>';
							    	listHtml +='<td>'+validnull(data.dottedLineDirectReptsList.list[i].positionTitle)+'</td>';					    	
						    	}
						    	listHtml +='</tr>';			    		
					    	}
					    }					    
					    $("#dottedLineReportsList tbody").html(listHtml);
				    }else{
				    	$("#dottedLineReportsListDiv").hide();
				    }
					  
					//
						   //contingent worker reports 
					if(data.contingentWorkerReptsList != null  && !data.contingentWorkerReptsList.empty  && data.contingentWorkerReptsList.granted){				    	
					    var listHtml = '' ;						    
					    var length = data.contingentWorkerReptsList.list.length;
					    hasContingentWorkerReports = true;
					    
					    for (var i = 0; i < length; i++) {
					    	listHtml +=    '<tr>';
					    	if( data.contingentWorkerReptsList.granted){
					    		listHtml +='<td><a href="'+validnull(data.contingentWorkerReptsList.list[i].sso)+'">'+validnull(data.contingentWorkerReptsList.list[i].lastName) +', '+ validnull(data.contingentWorkerReptsList.list[i].firstName) + '</a></td>';
					    		listHtml +='<td>'+validnull(data.contingentWorkerReptsList.list[i].sso)+'</td>';
						    	listHtml +='<td>'+validnull(data.contingentWorkerReptsList.list[i].positionTitle)+'</td>';					    	
					    	}
					    	listHtml +='</tr>';	    	
					    }
					    $("#contingentReportsList tbody").html(listHtml);
				    }else{
				    	$("#contingentReportsListDiv").hide();
				    	
				    }
					
					if(hasDirectReports || hasDottedLineDirectReports || hasContingentWorkerReports){
						 $("#viewAllReport").show();						
					}else{
						 $("#viewAllReport").html("");
						 $("#myReportModal").html("");
					}				
 
					}else{
						$("#unableToLoad").html("Current Information");
						$(".alert-box").show();
					}				
				}
			  },
			  error:function(xhr, ajaxOptions, thrownError){
				  
				  handleAjaxError(xhr, ajaxOptions, thrownError);					
			},
			  complete: function(){
				  spin_stop('#tab_user_information');
			  }
		});
		
	}
}
function populateContactsDemographics (){
	if (contactsDemographicsLoaded == false){
		contactsDemographicsLoaded = true;
		//$("#tab_demographics tr").show();// Show all <tr> that were hided because <td>
		//blockWorkArea(); 
		// load history
		spin_start('#tab_contacts_demographics');
		$.ajax({
			  url: getDocumentURL().url + '/json_contacts_demographics',
			  success: function(data) {
				if(data.success){
				    if(data.homeAddress != null && data.homeAddress.granted == true){
				    	var homeAddr = '';
				    	if(data.homeAddress.address1 !=null || data.homeAddress.address2 != null || data.homeAddress.address3 !=null){
				    	homeAddr += validnull(data.homeAddress.address1)+' '+validnull(data.homeAddress.address2)+' '+validnull(data.homeAddress.address3)+'<br>';
				    	}
				    	if(data.homeAddress.city !=null || data.homeAddress.state != null){
				    	homeAddr += validnull(data.homeAddress.city)+' '+validnull(data.homeAddress.state)+'<br>';
				    	}
				    	homeAddr += validnull(data.homeAddress.zip)+' '+validnull(data.homeAddress.country);
				    	$('#homeAddress').html(homeAddr);
						$('#personalEmail').html(data.homeAddress.personalEmail);
				    }else{
				    	$('#homeAddress').parent().hide();
				    }	
				    if(data.emergencyContact != null && data.emergencyContact.granted == true){
				    	$('#emergName').text(validnull(data.emergencyContact.fullName));
				    	$('#emergRelatn').text(validnull(data.emergencyContact.relationship));
				    	$('#emergPriPhone').text(validnull(data.emergencyContact.primaryPhone));
				    	$('#emergSecPhone').text(validnull(data.emergencyContact.secondaryPhone));
				    	$('#emergOwnPriPhone').text(validnull(data.emergencyContact.ownPrimaryPhone));
				    	$('#emergOwnSecPhone').text(validnull(data.emergencyContact.ownSecondaryPhone));
				    }else{
				    	$('#emergName').parent().hide();
				    	$('#emergRelatn').parent().hide();
				    	$('#emergPriPhone').parent().hide();
				    	$('#emergSecPhone').parent().hide();
				    	$('#emergOwnPriPhone').parent().hide();
				    	$('#emergOwnSecPhone').parent().hide();
				    }
				    if (data.perInfoRestricted != null && data.perInfoRestricted.granted){
					    $('#birthDate').text(data.perInfoRestricted.birthDate);
					    $('#age').text(data.perInfoRestricted.age);
					    $('#usEeoCategory').text(validnull(data.perInfoRestricted.usEeoCategory));
					    $('#disabilityId').text(validnull(data.perInfoRestricted.disabilityId));
					    if (data.veteranStatus == 'NOTVET'){
					    	$('#veteranStatus').text('');
					    } else {
					    	$('#veteranStatus').text(validnull(data.perInfoRestricted.veteranStatus));
					    }
				    } else {
					    $('#birthDate').parent().hide();
					    $('#age').parent().hide();
					    $('#usEeoCategory').parent().hide();
					    $('#disabilityId').parent().hide();
				    	$('#veteranStatus').parent().hide();
				    }
				    if(data.genderCitizenship != null && data.genderCitizenship.granted == true){
				    	$('#gender').text(data.genderCitizenship.gender);
				    	$('#citizenship').text(validnull(data.genderCitizenship.citizenShip));
				    }else{
				    	$('#gender').parent().hide();
				    	$('#citizenship').parent().hide();
				    }	
				}else{
					$("#unableToLoad").html("Contacts & Demographics");
					$(".alert-box").show();
				}
			  },
			error:function(xhr, ajaxOptions, thrownError){
				  handleAjaxError(xhr, ajaxOptions, thrownError);
			},
			  complete: function(){
				  spin_stop('#tab_contacts_demographics');
			  }
		});
	}else{
		
	}
}
function populateServiceDates (data){
	if (serviceDatesLoaded == false){
		serviceDatesLoaded = true;
	var serviceDates = data.serviceDates;
	var workAssignmentRestrd = data.workAssignmentRestrd;
	if (serviceDates != null && serviceDates.granted == true){
	    $('#dateFirstHired').text(validnull(serviceDates.dateFirstHired));
	    $('#acquiredServiceDate').text(validnull(serviceDates.acquiredServiceDate));
	    $('#adjustedServiceDate').text(validnull(serviceDates.adjustedServiceDate));	    
	    $('#geServiceYears').text(serviceDates.geServiceYears);
	} 
	
	//Month in business
	if (workAssignmentRestrd != null && workAssignmentRestrd.granted == true){
	    $('#monthsInBusiness').text(workAssignmentRestrd.monthsInBusiness);
	}
	}
}
function populateEmployeeHistory(){
	if(employeeHistoryLoaded == false){
		employeeHistoryLoaded = true;
		//$("#tab_employeehistory tr").show();// Show all <tr> that were hided because <td>
		//blockWorkArea();
		spin_start('#tab_work_history');
		$.ajax({
			  url: getDocumentURL().url + '/json_employeehistory',
			  success: function(data) {
					   		
				if(data!=null && data.success){
					
					populateServiceDates(data);
					
					var waHistory = data.workAssignmentHistoryInternal;
					
					if(waHistory != null && !waHistory.empty){						
						var employeeHistoryTable = "";
						if(waHistory.granted){							
							var length = (waHistory.list.length > 0 ) ? waHistory.list.length : waHistoryRestricted.list.length;
							
							for(var ii = 0; ii < length; ii++){
								
								employeeHistoryTable += "<tr class='clearfix'>";
								
								//Position
								employeeHistoryTable += "<td data-label='Title'>" + validnull(waHistory.list[ii].businessCard) + "</td>";
								if($("#empHistoryDataGroup").val()!=""){
								employeeHistoryTable += "<td data-label='GE Band'>" + validnull(waHistory.list[ii].corporateBand) + "</td>";
								}
								employeeHistoryTable += "<td data-label='Business'>" + validnull(waHistory.list[ii].geBusiness) + "</td>";
								employeeHistoryTable += "<td data-label='Location'>" + validnull(waHistory.list[ii].location) + "</td>";
								employeeHistoryTable += "<td data-label='Function'>" + validnull(waHistory.list[ii].jobFunction) + "</td>";
								employeeHistoryTable += "<td data-label='Start & End Date'>" + validnull(waHistory.list[ii].fromDate) + ' ' + validnull(waHistory.list[ii].toDate) + "</td>";
								if($("#empHistoryDataGroup").val()!=""){
								employeeHistoryTable += "<td data-label='Manager'>" + validnull(waHistory.list[ii].manager) + "</td>";
								}
								employeeHistoryTable += "</tr>";
							
							}	
							$('#table_employment_history tbody').html(employeeHistoryTable);													
							
						}else{
							$('#table_employment_history').hide();
						}	
					}
				}else{
					$("#unableToLoad").html("EMS Work History");
					$(".alert-box").show();
				}
				
           },
		error:function(xhr, ajaxOptions, thrownError){
        	   handleAjaxError(xhr, ajaxOptions, thrownError);
           },
			  complete: function(){
				  spin_stop('#tab_work_history');
			  }
		});		
		
	}	
}
function populateAssignmentHistory(){
	
	if (assignmentHistoryLoaded == false){
		assignmentHistoryLoaded = true;
		spin_start('#tab_work_history');
		//$("#tab_assign_history tr").show();// Show all <tr> that were hided because <td>
		
		//blockWorkArea(); 
		// load history
		$.ajax({
			  url: getDocumentURL().url + '/json_assignmenthistory',		  
			  contentType: 'application/json',
			  success: function(data) {		
				if(data!=null){				
					if(data.success){
						populateServiceDates(data);
					    var workAssigIntList = data.workAssigIntList;
					    var workAssigRestrictdList = data.workAssigRestrictdList;
					    
					   //Populate GE Assignment History Source HR					    
					    if((workAssigIntList!= null || workAssigRestrictdList!= null)
					    			&& ( !workAssigIntList.empty || !workAssigRestrictdList.empty ) ){
						    var tableHtml = '' ;
						    var length = workAssigIntList.list.length ;						    
						    for (var i = 0; i < length; i++) {
						    	tableHtml += '<tr class="clearfix">';
						    	if(workAssigIntList.granted && !workAssigIntList.empty){
						    		tableHtml +=    '<td data-label="Date">' + validnull(workAssigIntList.list[i].startDate) + '</td>';
						    		tableHtml +=    '<td data-label="Business">' + validnull(workAssigIntList.list[i].businessSegment) + '</td>';
						    		tableHtml +=    '<td data-label="Title">' + validnull(workAssigIntList.list[i].positionTitle) + '</td>';
						    		tableHtml +=    '<td data-label="Manager">' + validnull(workAssigIntList.list[i].managerName) + '</td>';
						    		tableHtml +=    '<td data-label="Function">' + validnull(workAssigIntList.list[i].jobFunction) + '</td>';
						    		tableHtml +=    '<td data-label="Location">' + validnull(workAssigIntList.list[i].address1) + ', ' + validnull(workAssigIntList.list[i].city) +', '  + validnull(workAssigIntList.list[i].state) +', ' + validnull(workAssigIntList.list[i].country) + '</td>';						    								    	
						    		if(workAssigRestrictdList.granted && !workAssigRestrictdList.empty ){
							    		tableHtml +=    '<td data-label="Band">' + validnull(workAssigRestrictdList.list[i].band) + '</td>';
							    	}
						    	
						    	}else{
						    		tableHtml += 	'<td></td> <td></td> <td></td> <td></td> <td></td> <td></td> <td></td>';					    		
						    	}
						    	tableHtml += "</tr>";
						     }
						    
						    $("#table_ohr_history tbody").html(tableHtml);
						    
						    if(workAssigRestrictdList !=  null && !workAssigRestrictdList.granted){
							    $('#table_ohr_history thead tr th:eq(6)').hide();
						    }
						    
					    }else{
					    	// Hide direct table if has not records
					    	$("#table_ohr_history").hide();
					    }
					}else{
						$("#unableToLoad").html("OHR Work History");
						$(".alert-box").show();
					}
				}  
			},
			error:function(xhr, ajaxOptions, thrownError){
				handleAjaxError(xhr, ajaxOptions, thrownError);
			},
			  complete: function(){
				  spin_stop('#tab_work_history');
			  }
		});
	}else{
		// Hides empty elements only for activated tab
		
	}
}
function populateEducation(){
	if (educationLoaded == false){
		educationLoaded = true;
		spin_start('#tab_education_training');
		//$("#tab_education tr").show();// Show all <tr> that were hided because <td>
		//blockWorkArea(); 
		// load history
		$.ajax({
			  url: getDocumentURL().url + '/json_educationtraining',
			  success: function(data) {
				if(data!=null){
					if(data.success){
						var educationList = data.educationList.list;
						var trainingHederList = data.trainingHederList.list;
						var programList = data.programList.list;
						// Populates education
						if(data.educationList!= null && !data.educationList.empty){						
							var tableHtml='';
						    for (var i = 0; i < educationList.length; i++) {
						    	tableHtml +='<h4 class="reset-bottom-margin"><strong>'+ validnull(educationList[i].university)+'</strong>, '+validnull(educationList[i].country) +'</h4>';
						    	tableHtml +=validnull(educationList[i].degree)+', '+validnull(educationList[i].major)+'<br>';
				              //tableHtml +='<span class="timestamp">1998-2000</span>';
						    }			    
						    $("#div_education").html(tableHtml);	
						}else{
					    	$("#div_education").hide();
					    }
						
						// Populates Training bar
						var leftBar ="";
						var rightBar ="";
						
						if(data.trainingHederList != null && !data.trainingHederList.empty){
							
							for (var i = 0; i < trainingHederList.length; i++) {		
								var screenUnder ="";
								var trainingList = trainingHederList[i].trainingList;
								var content = "";							
								content = "<h4><strong>" + validnull(trainingHederList[i].uiDisplayHeading) + "</strong></h4>";								

								if(data.self){									
									var isSelectedTraining = false;									
									if($.inArray(trainingHederList[i].uiDisplayHeading,data.optinTrainingList)>-1){
										isSelectedTraining=true;
									}									
									content += "<span class='hide-mobile-view optinTrnSpan'>";
									content += "<button type='button' id='optin_training_select_"+i+"' class='optin_training_select btn";
									if(isSelectedTraining){
										content +=	" dialog10 btn-primary";
									}else{
										content +=	" dialog9";
									}
									content +=	"'";
									content += " rel='dialog-popover' data-original-title='Share Training across GE?' data-placement='left'>";
									if(!isSelectedTraining){
										content +=	"Not ";
									}
									content += "Shared</button>";
									content += "<input id='optinTrainingSelect"+i+"' type='hidden' name='training' value='"+trainingHederList[i].uiDisplayHeading+"'></input>";
									content += "</span>";
								}
								
								
								
								if(trainingList!=null && trainingList.length > 0){								
									for (var j = 0; j < trainingList.length; j++) {
										if(trainingList[j].hasScreenUnder && screenUnder != trainingList[j].screenUnder ){
											screenUnder = trainingList[j].screenUnder;											
											content += "<h5 class='reset-bottom-margin'><strong>"+ validnull(screenUnder) +"</strong></h5>";
										}										
										content += validnull(trainingList[j].trainingTitle);
								    	if($("#trainingDataGroup").val()!=""){
								    	content +=', '+validnull(trainingList[j].completionDate);
								    	}
										content += "<br>";
									}
								}
								content += "</tbody ></table><br>";
								
								// Add html to LeftBar or RightBar.
								((i%2)==0)?leftBar+=content:rightBar+=content;							
							}
						}					
						// Add Bars Content
						$("#bar_training_left").html(leftBar);
						$("#bar_training_right").html(rightBar);					
						
						// Populates Program bar
						
						if(data.programList != null && !data.programList.empty){
							if(data.self){
								var isSelectedLPTraining = false;									
								if($.inArray("Leadership Programs",data.optinTrainingList)>-1){
									isSelectedLPTraining=true;
								}								
								var content = "";
								content += "<button type='button' id='optin_training_select_lp' class='optin_training_select btn";
								if(isSelectedLPTraining){
									content +=	" dialog10 btn-primary";
								}else{
									content +=	" dialog9";
								}
								content +=	"'";
								content += " rel='dialog-popover' data-original-title='Share Leadership Program across GE?' data-placement='left'>";
								if(!isSelectedLPTraining){
									content +=	"Not ";
								}
								content += "Shared</button>";
								content += "<input id='optinTrainingSelectlp' type='hidden' name='training' value='Leadership Programs'></input>";
								$("#optinTrainingSpanlp").html(content);								
							}
							
							var tableHtml='';
							for (var i = 0; i < programList.length; i++) {
								tableHtml += validnull(programList[i].name)+', '+validnull(programList[i].status);
						    	if($("#trainingDataGroup").val()!=""){
						    	tableHtml +=', '+validnull(programList[i].graduationYear);
						    	}
						    	tableHtml +='<br>';									
							}
							$("#div_leadership_programs_title").show();
							$("#div_leadership_programs").show();
							$("#div_leadership_programs").html(tableHtml); 
						}else{
							$("#div_leadership_programs_title").hide();
							$("#div_leadership_programs").hide();
							$("#optinTrainingSpanlp").hide();
						}
						initOptinTrnPopover();
					}else{
						$("#unableToLoad").html("Education & Training");
						$(".alert-box").show();
					}
				}
				
			},
			error:function(xhr, ajaxOptions, thrownError){
				handleAjaxError(xhr, ajaxOptions, thrownError);
			},
			  complete: function(){
				  spin_stop('#tab_education_training');
			  }
		});
	}else{		
	}
}

function populatePerformance(){
	if (performanceLoaded == false){
		performanceLoaded = true;
		//$("#tab_appraisal tr").show();// Show all <tr> that were hided because <td>
		//blockWorkArea(); 
		// load history
		spin_start('#tab_appraisal');
		$.ajax({
			url: getDocumentURL().url + '/json_performance',
			success: function(data) {
				if(data != null ){
					if(data.success){
						if(data.performance != null && data.performance.granted == true){
							$('#appraisalYear').text(validnull(data.performance.year));
							$('#overallPerformance').text(validnull(data.performance.overallPerformance));
							$('#overallGrowth').text(validnull(data.performance.overallGrowth));
							$('#overallRating').text(validnull(data.performance.overallRating));
							
						} else {
							$('#table_ratings').hide();
						}
						var growthValuesList = data.growthValues.list;
						if(growthValuesList!=null && !data.growthValues.empty > 0){						
							var tableHtml='';
						    for (var i = 0; i < data.growthValues.list.length; i++) {
						    	tableHtml += '<tr>';
						    	tableHtml +=    '<td><strong>' + growthValuesList[i].name + '</strong></td>';
						    	tableHtml +=    '<td>' + growthValuesList[i].rating + '</td>';
						    	tableHtml += '</tr>';
						    }	    
						    tableHtml += '<tr><td>&nbsp;</td></tr>';
						    $("#table_growth_values tbody").html(tableHtml);
						   
						    
						}else{
					    	// Hide table if does not have records
					    	$("#table_growth_values").hide();
					    }
						
						
						if(data.priorPerformance != null && data.priorPerformance.granted == true){
							$('#priorAppraisalYear').text(validnull(data.priorPerformance.year));
							$('#priorOverallPerformance').text(validnull(data.priorPerformance.overallPerformance));
							$('#priorOverallGrowth').text(validnull(data.priorPerformance.overallGrowth));
							$('#priorOverallRating').text(validnull(data.priorPerformance.overallRating));
							
						} else {
							$('#table_prior_ratings').hide();
						}
						var priorGrowthValuesList = data.priorGrowthValues.list;
						if(priorGrowthValuesList!=null && !data.priorGrowthValues.empty > 0){						
							var tableHtml='';
						    for (var i = 0; i < data.priorGrowthValues.list.length; i++) {
						    	tableHtml += '<tr>';
						    	tableHtml +=    '<td><strong>' + priorGrowthValuesList[i].name + '<strong></td>';
						    	tableHtml +=    '<td>' + priorGrowthValuesList[i].rating + '</td>';
						    	tableHtml += '</tr>';
						    }
						    tableHtml += '<tr><td>&nbsp;</td></tr>';
						    $("#table_prior_growth_values tbody").html(tableHtml);
						}else{
					    	$("#table_prior_growth_values").hide();
					    }
						
					}else{
						$("#unableToLoad").html("Appraisal");
						$(".alert-box").show();
					}
				}
			},
			error:function(xhr, ajaxOptions, thrownError){
				handleAjaxError(xhr, ajaxOptions, thrownError);
			},
			  complete: function(){
				  spin_stop('#tab_appraisal');
			  }
		});
	}else{		
	}
}

function populateCompensation(){
	if (compensationLoaded == false){
		lazyLoadJqueryValidate();
		compensationLoaded = true;
		spin_start('#tab_compensation');
		//$("#tab_compensation tr").show();// Show all <tr> that were hided because <td>
		//blockWorkArea(); 
		// load history
		$.ajax({
			url: getDocumentURL().url + '/json_compensation',
			success: function(data) {
				if(data != null){
					if(data.success){
						
						var compensationList = data.compensationList.list;
						var icList = data.icList.list;
						var stockOptList = data.stockOptList.list;
						var optsOutstdngList = data.optsOutstdngList.list;
						var restrctdStockOptList = data.restrictedStockOptList.list;
						var nextVestingOptList = data.nextVestingOptList.list;
						var ltPerformanceAwardList = data.ltPerformanceAwardList.list;
						var stockOptionTotals = data.stockOptionTotals;
						var optsOutstdngTotals = data.optsOutstdngTotals;
						var restctdStockOptTotals = data.restrctdStockOptTotals;
						
						var defaultCurrency = "USD";
						
						// populates Base Salary History
						if(compensationList!=null && !data.compensationList.empty && data.compensationList.granted){
							var tableHtml='';
							var total = data.totalCurrentComp;
							var currency=data.currency;
						    for (var i = 0; i < compensationList.length; i++) {
						    	tableHtml += "<tr>";
						    	var styleClass = "comp_val";
						    	//Future dated salary records should be highlighted in BOLD & blue 
						    	//A future dated salary record is any record where the Date is > Sys.Date
						    	if(compensationList[i].futureDate){
						    		styleClass = "future_date";
						    	}else{
						    		if(currency==null){
						    			//Currency must be the first Currency that it is not a future date.
						    			currency = compensationList[i].currency;
						    		}						    		
						    	}						    
						    	//Set Currence
						    	tableHtml +=    "<td class='comp_val' data-label='Date'><span class='nowrap'"+styleClass +"'>" + validnull(compensationList[i].efectiveDate) + "</span></td>";						    	
						    	//tableHtml +=    "<td class='left "+styleClass +" incCellType padding_left_7' "+ setTitle(compensationList[i].salaryReasonCode,12)+"title='"+validnull(compensationList[i].salaryReasonCode)+"'>" + truncate(validnull(compensationList[i].salaryReasonCode),12) + "</td>";
						    	tableHtml +=    "<td class='"+styleClass +"' data-label='Salary'>" + addCommas(validnull(compensationList[i].salary)) + "</td>";
						    	if(compensationList[i].changePercent == null){
						    		tableHtml +=    "<td class='"+styleClass +"' data-label='V%'>N/A</td>";
						    	}else{
						    		tableHtml +=    "<td class='"+styleClass +"' data-label='V%'>" + validnull(compensationList[i].changePercent.toFixed(1)) + "%</td>";
						    	}						    	
						    	tableHtml +=    "<td class='"+styleClass +"' data-label='Months'>" + validnull(compensationList[i].interval) + "</td>";
						    	tableHtml +=    "<td class='"+styleClass +"' data-label='Lump'>" + addCommas(validnull(compensationList[i].lumpAmmount)) + "</td>";						    	
						    	tableHtml +=    "<td class='"+styleClass +"' data-label='Currency'>" + validnull(compensationList[i].currency) + "</td>";
						    	tableHtml += "</tr>";
						    }				    
						    $("#table_base_salary_history tbody").html(tableHtml);						    
						    // Set NA values
						    $("#table_base_salary_history tbody tr:last td:eq(3)").text("N/A"); //V Percent
						    $("#table_base_salary_history tbody tr:last td:eq(4)").text("N/A"); //Interval
						    
						    // Set Total  Comp
						    if(currency!= null){						    	
						    	total = total + ' '+ currency;
						    }
						    
						    $('#total_curr_comp').html("<h5><strong>"+addCommas(total)+"</strong></h5>");
						    
						    //Total Compensation Converted to USD
						    if(data.currency!="USD"){
						    	$('#total_curr_comp_converted').html("<h5><strong>"+addCommas(data.totalCurrentCompConverted)+ " "+ defaultCurrency +"</strong></h5>");
						    }else{
						    	$('#total_curr_comp_converted').hide();
						    }	
						
						}else{
					    	// Hide table
					    	$("#table_base_salary_history").hide();
					    	$("#table_base_salary_history_title").hide();
					    	$("#table_total_current_comp").hide();			    	
					    }		
						
						// populates incentive compensation history table"
						if(icList!=null && !data.icList.empty && data.icList.granted){
							var tableHtml='';
						    for (var i = 0; i < icList.length; i++) {						    	
						    	var styleClass = "comp_val";						    	
						    	//Future dated salary records should be highlighted in BOLD & blue 
						    	//A future dated salary record is any record where the Date is > Sys.Date
						    	if(icList[i].futureDate){
						    		styleClass = "future_date";
						    	}						    	
						    	tableHtml += "<tr>";
						    	tableHtml +=    "<td class='"+styleClass +"' data-label='Performance Year'>" + validnull(icList[i].perfYear) + "</td>";
						    	tableHtml +=    "<td class='"+styleClass +"' data-label='Type'>" + validnull(icList[i].type) + "</td>";
						    	tableHtml +=    "<td class='"+styleClass +"' data-label='Award'>" + addCommas(validnull(icList[i].amount)) + "</td>";
						    	if(icList[i].changePercent == null){
						    		tableHtml +=    "<td id='v_percent' class='"+styleClass +"' data-label='V%'>N/A</td>";
						    	}else{
						    		tableHtml +=    "<td id='v_percent' class='"+styleClass +"' data-label='V%'>" + validnull(icList[i].changePercent.toFixed(1)) + "%</td>";
						    	}
						    	tableHtml +=    "<td class='"+styleClass +"' data-label='Currency'>" + validnull(icList[i].currency) + "</td>";
						    	tableHtml += "</tr>";
						    }
						    $("#table_incentive_comp_history tbody").html(tableHtml);
						    
						    // Set NA value
						    $("#table_incentive_comp_history tbody tr:last #v_percent").text("N/A");
						    
						}else{
					    	// Hide table
					    	$("#table_incentive_comp_history").hide();
					    	$("#table_incentive_comp_history_title").hide();
					    }
						
						// Populates Long Term Compensation div		
						if(stockOptList!=null && !data.stockOptList.empty && data.stockOptList.granted ){
							var colLength=1;
							var tableHtml='';
						    for (var i = 0; i < stockOptList.length; i++) {
						    	
						    	// populates Stock Option Grant History
						    	tableHtml += "<tr class='stockVal'>";
						    	tableHtml +=    "<td data-label='Date'><span class='nowrap'>" + validnull(stockOptList[i].dateGranted) + "</span></td>";
						    	tableHtml +=    "<td data-label='Price'>" + addCommas(validnull(stockOptList[i].price)) + "</td>";
						    	tableHtml +=    "<td data-label='# Shares'>" + addCommas(validnull(stockOptList[i].numShares)) + "</td>";
						    	
						    	if(optsOutstdngList!=null && !data.optsOutstdngList.empty && data.optsOutstdngList.granted ){														
						    		tableHtml +=    "<td data-label='# Options Exercised'>" + addCommas(validnull(optsOutstdngList[i].exercised)) + "</td>";
							    	
						    		tableHtml +=    "<td data-label='Options Outstanding'>" + addCommas(validnull(optsOutstdngList[i].total)) + "</td>";
						    		tableHtml +=    "<td data-label='Options Vested'>" + addCommas(validnull(optsOutstdngList[i].sharedVested)) + "</td>";
							    	tableHtml +=    "<td data-label='Options Unvested'>" + addCommas(validnull(optsOutstdngList[i].sharedUnvested)) + "</td>";

						    	}
						    	
						    	tableHtml += "</tr>";
						    	
						    	colLength++;
						    	
						    }
						    tableHtml += "<tr><td style='background-color: #ffffff;' colspan='"+colLength+"'>&nbsp;</td></tr>";
						    $("#table_tr_stock_option").replaceWith(tableHtml);
							$('#long_term_total_opts_num_shares').html(stockOptionTotals.numShares);
							if(optsOutstdngList!=null && !data.optsOutstdngList.empty && data.optsOutstdngList.granted ){
								$('#long_term_total_opts_exercised').html(addCommas(optsOutstdngTotals.exercided));
								$('#long_term_total_opts_total').html(addCommas(optsOutstdngTotals.total));
								$('#long_term_total_opts_vested').html(addCommas(optsOutstdngTotals.sharedVested));
								$('#long_term_total_opts_unvested').html(addCommas(optsOutstdngTotals.sharedUnvested));
								$('#long_term_total_value_total').html('0');
								$('#long_term_total_value_vested').html('0');
								$('#long_term_total_value_unvested').html('0');
							}
														
							
						}else{
					    	// Hide tables that belongs to Long Term Compensation
							// div
							$(".stockOptList").hide();
					    	$("#table_stock_option").hide();
					    	$(".stockVal").hide();
					    }
												
						
						// populates Restricted Stock Unit Grant div
						if(restrctdStockOptList!=null && !data.restrictedStockOptList.empty && data.restrictedStockOptList.granted){
							
							var tableHtml='';
						    for (var i = 0; i < restrctdStockOptList.length; i++) {
						    	// Populates RSU Grant History
						    	tableHtml += "<tr>";
						    	tableHtml +=    "<td data-label='Date'><span class='nowrap'>" + validnull(restrctdStockOptList[i].dateGranted) + "</span></td>";
						    	tableHtml +=    "<td data-label='Price @ Grant'>" + addCommas(validnull(restrctdStockOptList[i].price)) + "</td>";
						    	tableHtml +=    "<td data-label='Granted'>" + addCommas(validnull(restrctdStockOptList[i].numShares)) + "</td>";
						    	tableHtml +=    "<td data-label='Unvested'>" + addCommas(validnull(restrctdStockOptList[i].sharedUnvested)) + "</td>";
						    	tableHtml += "</tr>";						    	
						    }
						    tableHtml += "<tr><td style='background-color: #ffffff;' colspan='4'>&nbsp;</td></tr>";
						    $("#table_tr_rsu_grant_history").replaceWith(tableHtml);
						    
						    // populates Restricted Stock Unit Grant Totals
							$('#restrctd_total_rsus_granted').html(addCommas(restctdStockOptTotals.numGranted));				
							$('#restrctd_total_rsus_unvested').html(addCommas(restctdStockOptTotals.unvested));
							$('#restrctd_total_value_unvested').html('0');							
						}else{						
							$(".rsugrant").hide();
					    	$("#table_tr_rsu_grant_history").hide();					    	
					    }
						
						
						// populates Next Vesting in  Unit Grant div
						if(nextVestingOptList!=null && !data.nextVestingOptList.empty && data.nextVestingOptList.granted){							
							var tableHtml='';
						    for (var i = 0; i < nextVestingOptList.length; i++) {
						    	
						    	// Populates Restricted Stock Next Vesting Date
						    	tableHtml += "<tr>";
						    	tableHtml +=    "<td data-label='Date'><span class='nowrap'>" + validnull(nextVestingOptList[i].nextVestingDate) + "<span></td>";
						    	tableHtml +=    "<td data-label='# Vesting'>" + addCommas(validnull(nextVestingOptList[i].nextVestingAmount)) + "</td>";				    	
						    	tableHtml += "</tr>";
						    }
						   
						    $("#table_next_vesting_date tbody").html(tableHtml);					    
							
						}else{
					    	// Hide table	
							$(".nextvesting").hide();
					    	$("#table_next_vesting_date").hide();					    	
					    }
						
						
						// populates Program Participation div
						
						if(ltPerformanceAwardList!=null && !data.ltPerformanceAwardList.empty){							
							var tableLeftHtml='';					
						    for (var i = 0; i < ltPerformanceAwardList.length; i++) {
						    	// Populates RSU Grant History
						    	tableLeftHtml += "<tr>";
						    	tableLeftHtml +=    "<td data-label='Program Year'>" + validnull(ltPerformanceAwardList[i].programYear) + "</td>";
						    	tableLeftHtml +=    "<td data-label='Date'>" + validnull(ltPerformanceAwardList[i].date) + "</td>";
						    	tableLeftHtml +=    "<td data-label='Category'>" + validnull(ltPerformanceAwardList[i].category) + "</td>";
						    	tableLeftHtml += "</tr>";
						    }				    
						    $("#table_program_participation tbody").html(tableLeftHtml);
 
						}				    	
						else{
					    	// Hide table
							$(".ltpa").hide();							
					    	$("#table_program_participation").hide();
					    	$(".stockVal").css("margin-left","0");
					    }
					}
					else{
						$("#unableToLoad").html("Compensation");
						$(".alert-box").show();
						
					}
				}				
			},
			error:function(xhr, ajaxOptions, thrownError){
				handleAjaxError(xhr, ajaxOptions, thrownError);
			},
			complete: function(){
				  spin_stop('#tab_compensation');
			}
		});
	}else{
		
	}
}
function populateMyClients(){
	if(!myClientsLoaded ){
		myClientsLoaded = true;
		$("#tab_my_clients tr").show();// Show all <tr> that were hided because <td>
		// Block Work area while data is populated
		spin_start('#tab_hr_client_managers');
		
		$.ajax({
			  url: getDocumentURL().url + '/json_myclients',			  
			  contentType: 'application/json',
			  success: function(data) {	
				  
				  if(data.myClientsList != null){
						 if((!data.myClientsList.empty ) &&
									(data.myClientsList.granted )){
					    	var tableHtml = '' ;	
					    	var length = data.myClientsList.list.length;
					    	for (var i = 0; i < length; i++) {
							    	
					    		tableHtml += '<tr>';
					    		tableHtml += 	'<td data-label="Name">';
					    		tableHtml +=	'<a href="'+validnull(data.myClientsList.list[i].sso)+'">' + validnull(data.myClientsList.list[i].lastName) + ', ' + validnull(data.myClientsList.list[i].firstName) + '</a></td>';
					    		tableHtml +=    '<td data-label="SSO">' + validnull(data.myClientsList.list[i].sso) + '</td>';
					    		tableHtml +=    '<td data-label="Title">' + validnull(data.myClientsList.list[i].positionTitle) + '</td>';
					    		tableHtml +=    '<td data-label="Business">' + validnull(data.myClientsList.list[i].business) + '</td>';
					    		tableHtml +=    '<td data-label="Sub Business">' + validnull(data.myClientsList.list[i].subBusiness) + '</td>';
					    		tableHtml +=    '<td data-label="Organization">' + validnull(data.myClientsList.list[i].org) + '</td>';
					    		tableHtml += '</tr>';
					    	}
					    	$("#table_my_clients tbody").html(tableHtml);
					    	
					    	$("#table_my_clients tbody tr:even").css("background-color","#F5F5F5"); 
						 }else{
							 if(data.myClientsList.granted){
								 $("#table_my_clients").hide();		
								 $("#tab_hr_client_managers p").show();	
							 }
						 }
					 }
				  
			  },
			  error: function(xhr, ajaxOptions, thrownError){
				  handleAjaxError(xhr, ajaxOptions, thrownError);
			  },
			  complete: function(){
				  spin_stop('#tab_hr_client_managers');
			  }
				  
		});
	}
}

function populateMyReports(){
	$("#myReportModal").modal('show');
	if(!myReportsLoaded ){
		myReportsLoaded = true;
		spin_start('.report-modal-body');
		$.ajax({
			  //url: getDocumentURL().url + '/json_myreports',
			  url: '../../data/213004520/json_myreports.json',			  
			  contentType: 'application/json',
			  success: function(data) {	
				  
				  if(data!=null && data.success){
						//Direct popup
						 if(data.directReportList != null  && !data.directReportList.empty  && data.directReportList.granted){
							 $("#directReporttab").show();
							var listHtml = '' ;						    
							var length = data.directReportList.list.length;
							
							for (var i = 0; i < length; i++) {
								
								if( data.directReportList.granted){
									listHtml +=    '<tr>';
									if( data.directReportList.granted){
										listHtml +='<td><a href="'+validnull(data.directReportList.list[i].sso)+'">'+validnull(data.directReportList.list[i].lastName) +', '+ validnull(data.directReportList.list[i].firstName) + '</a></td>';
										listHtml +='<td>'+validnull(data.directReportList.list[i].sso)+'</td>';
										listHtml +='<td>'+'<a href="mailto:'+validnull(data.directReportList.list[i].email)+'">'+validnull(data.directReportList.list[i].email)+'</td>';
										listHtml +='<td>'+validnull(data.directReportList.list[i].positionTitle)+'</td>';		
										listHtml +='<td>'+validnull(data.directReportList.list[i].fnction)+'</td>';	
										listHtml +='<td>'+validnull(data.directReportList.list[i].business)+'</td>';
										listHtml +='<td>'+validnull(data.directReportList.list[i].subBusiness)+'</td>';
									}
									listHtml +='</tr>';			    		
								}
							}
							$("#allDirReportstable tbody").html(listHtml);
							$("#directReportstable tbody").html(listHtml);		  
						}else{							
							//$("#directReportstable").parent().html("No Direct Reports");
							$("#allDirReportstable").hide();
							$("#allDirReportstable").prev("h5").hide();
							$("#directReportsdiv").hide();
							$("#directReporttab").hide();
						}

						//Dotted popup
						if(data.dottedReportList != null  && !data.dottedReportList.empty  && data.dottedReportList.granted){
						$("#dottedReporttab").show();
						var listHtml = '' ;						    
						var length = data.dottedReportList.list.length;
						for (var i = 0; i < length; i++) {
							
							if( data.dottedReportList.granted){
								listHtml +=    '<tr>';
								if( data.dottedReportList.granted){
									listHtml +='<td><a href="'+validnull(data.dottedReportList.list[i].sso)+'">'+validnull(data.dottedReportList.list[i].lastName) +', '+ validnull(data.dottedReportList.list[i].firstName) + '</a></td>';
									listHtml +='<td>'+validnull(data.dottedReportList.list[i].sso)+'</td>';		
									listHtml +='<td>'+'<a href="mailto:'+validnull(data.dottedReportList.list[i].email)+'">'+validnull(data.dottedReportList.list[i].email)+'</td>';	
									listHtml +='<td>'+validnull(data.dottedReportList.list[i].positionTitle)+'</td>';		
									listHtml +='<td>'+validnull(data.dottedReportList.list[i].fnction)+'</td>';	
									listHtml +='<td>'+validnull(data.dottedReportList.list[i].business)+'</td>';
									listHtml +='<td>'+validnull(data.dottedReportList.list[i].subBusiness)+'</td>';
								}
								listHtml +='</tr>';			    		
							}
						}
						$("#allDotReportstable tbody").html(listHtml);
						$("#dottedLineReportstable tbody").html(listHtml);
						}else{                                                                  
						//$("#dottedLineReportstable").parent().html("No Dotted Line Reports");
						$("#allDotReportstable").hide();
						$("#allDotReportstable").prev("h5").hide();
						$("#dottedLineReportsDiv").hide();
						$("#dottedReporttab").hide();
						}
						//Contingent popup
						 if(data.contingentReportList != null  && !data.contingentReportList.empty  && data.contingentReportList.granted){
							 $("#contingentReporttab").show();
							 var listHtml = '' ;						    
							var length = data.contingentReportList.list.length;
							for (var i = 0; i < length; i++) {
								
								if( data.contingentReportList.granted){
									listHtml +=    '<tr>';
									if( data.contingentReportList.granted){
										listHtml +='<td><a href="'+validnull(data.contingentReportList.list[i].sso)+'">'+validnull(data.contingentReportList.list[i].lastName) +', '+ validnull(data.contingentReportList.list[i].firstName) + '</a></td>';
										listHtml +='<td>'+validnull(data.contingentReportList.list[i].sso)+'</td>';
										listHtml +='<td>'+'<a href="mailto:'+validnull(data.contingentReportList.list[i].email)+'">'+validnull(data.contingentReportList.list[i].email)+'</a>'+'</td>';
										listHtml +='<td>'+validnull(data.contingentReportList.list[i].positionTitle)+'</td>';
										listHtml +='<td>'+validnull(data.contingentReportList.list[i].vendor)+'</td>';	
										listHtml +='<td>'+validnull(data.contingentReportList.list[i].fnction)+'</td>';	
										listHtml +='<td>'+validnull(data.contingentReportList.list[i].business)+'</td>';
										listHtml +='<td>'+validnull(data.contingentReportList.list[i].subBusiness)+'</td>';
									}
									listHtml +='</tr>';			    		
								}
							}
							$("#allContReportsTable tbody").html(listHtml);
							$("#contingentReportsTable tbody").html(listHtml);
						 }
						  else{                                                                  
							//$("#contingentReportsTable").parent().html("No Contingent Workers");
							$("#allContReportsTable").hide();
							$("#allContReportsTable").prev("h5").hide();
							$("#contingentReportsDiv").hide();
							$("#contingentReporttab").hide();						
						}
						 
				  }
				  
			  },
			  error: function(xhr, ajaxOptions, thrownError){
				  handleAjaxError(xhr, ajaxOptions, thrownError);
			  },
			  complete: function(){
				  spin_stop('.report-modal-body');
			  }
				  
		});
	}
	
}	

//UTF definitions on the last line are there to align with Oracles CONVERT US7ASCII missing characters
function replaceSpecialChars(str){
	   str = encodeURIComponent(str.toLowerCase());
	   str = escape(str);
	   str=str.replace(/%27/g,'[$27]');
 return str;
}

function setOptinSharing(type, value){
	$.post( getDocumentURL().url + '/optin_sharing', {type: type, value:value}, 
		function(){
	});
}
function setOptinTrainingSharing(){
	$.post( getDocumentURL().url + '/set_optin_sharing_training', 
	{training:trainingSelected, delete_flag :toDelTraining},
	function() {

	});
}
function populateWorkHistory(activeSubTab){
	$("#tab_nav_work_history .tab-content .tab-pane").hide();
	$("#tab_nav_work_history ul.nav li").removeClass("active");	
	$("#tab_nav_work_history .tab-content .tab-pane").removeClass("active");
	if(activeSubTab=='#tab_employment_history'){
		//$("#optin_empHistory_shareBtn").show();
		$("#tab_nav_work_history ul.nav li:first").addClass("active").show();
		$("#tab_employment_history").addClass("active").show();
		populateEmployeeHistory();
	}else if(activeSubTab=='#tab_ohr_history'){
		//$("#optin_empHistory_shareBtn").hide();
		$("#tab_nav_work_history ul.nav li:last").addClass("active").show();
		$("#tab_ohr_history").addClass("active").show();
		populateAssignmentHistory();
	}
}
function sidrCollapse(){
	 if ($(window).width() >= 300 && $(window).width() <= 979) {
		    var $navbar = $( '.navbar-inner > .container', this.element );
		    var $items = $navbar.children('.pull-right').children(':not(.btn[data-toggle="collapse"])');
		    var $target = $( '.primary-navbar > .container > .responsive-elements', this.element );
		    if ( !$target.size() ) {
			    $( '.primary-navbar > .container', this.element ).prepend( $( '<div class="responsive-elements"></div>' ) );
			    $target = $( '.primary-navbar > .container > .responsive-elements', this.element );
		    }
		    $target.append($items);
		    if(!$("#search-div-col").hasClass("menu-collapsed")){
		    	$("#search-div-col").show();
		    	$("#search-div-col").addClass("menu-collapsed")
			    $("#search-div-col").html($("#search-div").html());
			    $("#search-div").children().remove();
			    $("#search-div").hide();
			    $("#header-buttons-col").show();
		    	$("#header-buttons-col").html($("#header-buttons").html());
		    	$("#header-buttons").children().remove();
			    $("#header-buttons").hide();
		    }
	 }else {
			$("#search-div").show();
			$("#header-buttons").show();
			if($("#search-div-col").hasClass("menu-collapsed")){
		    $("#search-div").html($("#search-div-col").html());
		    $("#header-buttons").html($("#header-buttons-col").html());
			}
			$("#search-div-col").removeClass("menu-collapsed");
		    $("#search-div-col").children().remove();
		    $("#search-div-col").hide();
		    $("#header-buttons-col").children().remove();		    
		    $("#header-buttons-col").hide();
	 }
}
function tableOpenClose(){
	$('.table-mobile-view.table-open-close tr').append('<a href="#" class="btn btn-small table-accordion-toggle"><i class="icon-ico_chevron_down_sm"></i></a>');
    $('.table-mobile-view.table-open-close tr').addClass('closed');
    $('.table-mobile-view.table-open-close tr:first-child').removeClass('closed');
    
    $('.table-accordion-toggle').on('click',function() {
        $(this).closest('tr').toggleClass('closed');
        return false;
    });
}
function lazyLoadJqueryValidate(){
	require(["jquery.validate"], function(){
		$("#stockOptionsValuationForm").validate({
			  rules: {
			    field: {
				  min: 1,
				  max: 200,			  
			      required: true,
			      number: true
			    }
			  }
		});		
	});
}
function getPdfMenuPersistence(){
   var menuParameters = null;
   $.ajax({
		  url: getDocumentURL().url + "/pdf_menu_persistence",
		  async: false,
		  cache: false,
		  success: function(data) {				   		
			  if(data!=null){
				  menuParameters = data;
			  }else{
					$("#pdfDownload").find("input").each(function(index){
						$(this).attr("checked", "checked");
					});
			  }
		  }
	});
	return menuParameters;
}
function setPdfMenuPersistence(param){
	if(param.sortorder!=null){	
		var ul = $("#sortable"),
	    items = $("#sortable").children();
		for (var i = param.sortorder.length-1; i >= 0; i--) {
		    ul.prepend( ul.find("div[data-value="+param.sortorder[i]+"]"));
		}
	}
	if(param.columns!=null){
		for(var i = 0; i < param.columns.length; i++){
			$("#pdfDownload").find("input[value="+param.columns[i]+"]").prop("checked",true);
		}
	}else {
		$("#pdfDownload").find("input").each(function(index){
			$(this).prop("checked",true);
		});
	}
}
function lazyLoadJqueryUISortable(){
	require(["jqueryui-sortable"], function(){
	pdfMenuPersistence = getPdfMenuPersistence();
	
	setPdfMenuPersistence(pdfMenuPersistence);
	
	
	$("#sortable").sortable({axis:"y"}).disableSelection(); 
	
	$("#selectallPersonalInformation").on('click',function(){
		if(this.checked) {
            $('.checkbox1').each(function() {
                this.checked = true;             
            });
        }else{
            $('.checkbox1').each(function() {
                this.checked = false;                      
            });         
        }
	});
	$(".checkbox1").on('click',function(){
		if($(".checkbox1").length==$(".checkbox1:checked").length){
			$("#selectallPersonalInformation").prop("checked",true);
		}else{
			$("#selectallPersonalInformation").removeAttr("checked");
		}
	});
	
	$("#selectallContactDemographics").on('click',function(){
		if(this.checked) {
            $('.checkbox2').each(function() {
                this.checked = true;             
            });
        }else{
            $('.checkbox2').each(function() {
                this.checked = false;                      
            });         
        }
	});
	$(".checkbox2").on('click',function(){
		if($(".checkbox2").length==$(".checkbox2:checked").length){
			$("#selectallContactDemographics").prop("checked",true);
		}else{
			$("#selectallContactDemographics").removeAttr("checked");
		}
	});
	
	$("#selectallWorkHistory").on('click',function(){
		if(this.checked) {
            $('.checkbox3').each(function() {
                this.checked = true;             
            });
        }else{
            $('.checkbox3').each(function() {
                this.checked = false;                      
            });         
        }
	});
	$(".checkbox3").on('click',function(){
		if($(".checkbox3").length==$(".checkbox3:checked").length){
			$("#selectallWorkHistory").prop("checked",true);
		}else{
			$("#selectallWorkHistory").removeAttr("checked");
		}
	});
	

	});
}
function initOptinTrnPopover(){
	$(".optin_training_select").popover({
		trigger: 'click',
		container: 'body',
		html:true,
		content:function(){
			trainingSelectedId = $(this).attr("id");			
			if($(this).hasClass("dialog9")){				
				return $("#dialog9").html();
			}else if($(this).hasClass("dialog10")){
				return $("#dialog10").html();				
			}
	    }
	}).on("shown.bs.popover",function(){
		$(".optinShareBtnTrn").on("click",function(){	
			$('[rel="dialog-popover"]').popover('hide');
			if($('#'+trainingSelectedId).hasClass("dialog9")){
				$('#'+trainingSelectedId).addClass("dialog10");
				$('#'+trainingSelectedId).addClass("btn-primary");
				$('#'+trainingSelectedId).removeClass("dialog9");
				$('#'+trainingSelectedId).text("Shared");
				toDelTraining=false;
			}else if($('#'+trainingSelectedId).hasClass("dialog10")){
				$('#'+trainingSelectedId).addClass("dialog9");
				$('#'+trainingSelectedId).removeClass("btn-primary");
				$('#'+trainingSelectedId).removeClass("dialog10");
				$('#'+trainingSelectedId).text("Not Shared");
				toDelTraining=true;
			}
			trainingSelected=$('#'+trainingSelectedId).parent().find('input').val();
			setOptinTrainingSharing();
		});
		$(".optinCancelBtn").on("click",function(){				
			$('[rel="dialog-popover"]').popover('hide');
		});
	});	
}

function typeaheadSearch(){
	/*$(document.body).on("blur","#search",function(e){
		$("ul.typeahead").hide();
	});
	$(document.body).on("focus","#search",function(e){
		if($("ul.typeahead li").size()>0){
			$("ul.typeahead").show();
		}
	});*/
	$(document.body).on("keypress keydown keyup blur focus","#search",function(e){
		var key = (e.keyCode ? e.keyCode : e.which);
		if(key == 13) {
			openTypeAheadSearchResults();
			e.preventDefault();
		//}else if(key == 8 || key == 9 || key == 46 ){
		}else{
			setTimeout(function(){			
			//var c = String.fromCharCode(key);
			var typeaheadSelectnew = $("#search").val();
			if(typeaheadSelect != typeaheadSelectnew){
			typeaheadSelect = typeaheadSelectnew;
			var length = (typeaheadSelect==null||typeaheadSelect==undefined||typeaheadSelect=="")?0:typeaheadSelect.length;
			if(length>2){
				counter++;
			$.ajax({
				url: "../search/searchtypeahead?query=" + replaceSpecialChars(typeaheadSelect) +"&c="+counter,
				//data: {'query' : replaceSpecialChars(request.term)},
				dataType: "json",
				success: function(data) {
					if(data!=null && data.counter == counter){
						if(data.success){							
							if(data.autoComplete!= null){
								var content = "";
								$.each( data.autoComplete.rows, function(index, item){
									content += '<li data-value="'+item.label+'" class=""><a href="'+item.value+'">'+item.label+'</a></li>';
								});
								content += '<li id="moreElement" data-value="More..." class=""><a href="#"><strong>More...</strong></a></li>';								
								$("ul.typeahead").html(content);								
							}else{
								var errorMessage = (data.errorMessage != null && data.errorMessage != undefined)? data.errorMessage : ERROR_MSG; 
								//alert(errorMessage);
								//if($("ul.typeahead li").size()<1){
								//	$("ul.typeahead").hide();
								//}
							}						 
						}
					}
				},
				error:function(xhr, ajaxOptions, thrownError){
					//loaderToggle("#imgSearch", 'stop');
					handleAjaxError(xhr, ajaxOptions, thrownError);
				}
			});
			
		}else{
			//$("ul.typeahead").hide();
		}
			}
	},0);
		}
		
				
	});
}
function openTypeAheadSearchResults(){
	if ( typeaheadSelect != "" && typeaheadSelect != null)
	{
		$("form.navbar-search").removeClass("open");
	    sidr_close();
	    spin_start("body");
	    var $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","./search");
	    var $input=$(document.createElement('input')).attr('name','page').val("typeaheadsearchresults");
	    var $input2=$(document.createElement('input')).attr('name','query').val(typeaheadSelect);
	    $form.append($input).append($input2);
	    $("body").append($form);
	    $form.submit();
	    //window.location.href="../search?page=typeaheadresults";
	}
}

function openSearchResults(){
	    sidr_close();
	    spin_start("body");
	    var $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","./search");
	    var $input=$(document.createElement('input')).attr('name','page').val("searchresults");
	    $form.append($input);
	    $("body").append($form);
	    $form.submit();
}
