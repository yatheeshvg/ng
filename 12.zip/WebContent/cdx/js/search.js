var profilePhoto=null;
var typeaheadSelect = null;
var selectElement = null;
var hideAdditionalSearch = true;
var selectElements = [];
var searchResultLabel = [];
var searchResult = {};
var spinner = null;
var ERROR_MSG = "Internal error";
var dialogInitialized = false;
var facetInitialized = false;
var bandVisibility = false;
var facetSearch = false;
var searchHist = false;
var searchParameters = null;
var facetParameters = null;
var sortVal = "";
var totalSearchResults = 0;
var offset = 0;
var count = 20;
var counter = 0;
var catalogService = ['search/ifg', 'search/business', 'search/function', 
                      'search/region', 'search/country', 'search/leadershipProgram'];
var opts = {
		  lines: 17, 
		  length: 17, 
		  width: 5, 
		  radius: 30, 
		  corners: 1, 
		  rotate: 0, 
		  direction: 1, 
		  color: '#000',
		  speed: 1.1, 
		  trail: 58, 
		  shadow: false, 
		  hwaccel: false, 
		  className: 'spinner', 
		  zIndex: 2e9, 
		  top: '50%', 
		  left: '50%'
		};
var spinner = null;
require(['jquery', 
         'spin',
         'bootstrap',
         'mds-navbar',
         'backtotop'
         ], function($,Spinner){

	selectElements = [$('select[name=ifg]'), $('select[name=business]'), $('select[name=function]'),
	                      $('select[name=region]'), $('select[name=country]'), $('select[name=leadershipProgram]')];
	spinner=new Spinner(opts).spin();
	spin_start('body');
	profilePhoto=$('#photoURL').val();
	bandVisibility = $('#has_clientSearch').val();
	if($("#is_searchResults").val()=='true'){
		toggleToSearchResults();
		callSearchLucene("history");
		//initFacetSearch();
	}else{
		toggleToLuceneSearchScreen();
		searchHist = true;
	}
	$(document).ready(function(){
		$('body').show();
		$('body').append('<div class="sidr-overlay push-menu"></div>');
	    var isTouchDevice = 'ontouchstart' in document.documentElement;
	    if (!isTouchDevice) {
	      $('[rel=tooltip]').tooltip({ container: 'body' });
	    }

	    $('[rel=popover]').popover({ trigger: 'click' }).on('click', function(e) {
	      e.preventDefault();
	    });

	    $('.navbar').navbar();
		
	    // Disable zoom only on start for iOS. Zooming still works post load --
		// still don't like this
	    if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i)) {
	      var viewportmeta = document.querySelector('meta[name="viewport"]');
	      if (viewportmeta) {
	        viewportmeta.content = 'width=device-width, minimum-scale=1.0, maximum-scale=1.0, initial-scale=1.0';
	        document.body.addEventListener('gesturestart', function () {
	          viewportmeta.content = 'width=device-width, minimum-scale=0.25, maximum-scale=1.6';
	        }, false);
	      }
	    }	  
		
    	$('#responsive-menu-button').on('click tap',function(){	
    	  if(!( $( '#responsive-menu-button' ).hasClass('togglemenu'))){
    		  sidr_open();
    	  }else{
    		  sidr_close();
    	  }
    	});
		
    	sidrCollapse();
    	$(window).on('resize', function (event) {
    		sidrCollapse();
    	});
		
		// Exit form function If it is a error page
		if($('#error_page').length>0){
			return;
		}
		
		$("#container ul.nav li").on('click tap',function(){	
			sidr_close();
			var activeContainer = $(this).find("a").attr("href");
			initContainer(activeContainer);
			return false;
		});	
		
		typeaheadSearch();
		
		$(".helpVertical").on("click tap",function () {		
			// $('div').scrollTop(0);
			$(".first-run-overlay").css("height",$(document).height()+"px");
			$(".first-run-overlay,.first-run-sprite").show();
			return false;
		});

		$(".close-btn").on("click tap",function () {
			$(".first-run-overlay,.first-run-sprite").hide();
			return false;
		});
	    
		/*
	    $("#advancedSearch input[name='sso']").on("keydown",function(e){
	    	return keyDownEventSso(e);
	    });

	    $("#advancedSearch input[name='managerSso']").on("keydown",function(e){
	    	return keyDownEventSso(e);
	    });
	    */
    
	    $(document.body).on("click tap","#search-btn",function(e){
			if ( typeaheadSelect != "" || typeaheadSelect != "" || typeaheadSelect != $('#search').attr('placeholder'))
			{
				sidr_close();
				openTypeAheadSearchResults();		
			}
			e.preventDefault();
		});
		
		$(document.body).on("click tap","#searchResultsBtn",function(e){
				sidr_close();
				toggleToSearchResults();
				if(searchHist){
					callSearchLucene("history");
				}
				e.preventDefault();
		});
		// Excel
		$("#searchExcel").on('click tap', function(event){
			window.location.href= "../search/excel" + (sortVal!=""?"?sortBy="+sortVal:"");
		});

		// Advanced Search
		$(document.body).on("click tap","#advancedSearchBtn",function(e){
			    sidr_close();
			    spin_start("body");
			    toggleToLuceneSearchScreen();
				// $("#advancedSearch").show();
				spin_stop("body");
			    e.preventDefault();
		   });  
		
	    // LuceneSearch
		$("#luceneSearchBtn").on('click tap', function(event){
			callSearchLucene("all");
			event.preventDefault();
		});
		// Modify Search
		$("#modifySearchLink").on('click tap', function(event){
			toggleToLuceneSearchScreen();
		});

		$(window).on("scroll",function(){
			if($('#div_search').is(":visible")== true){
				if ($(window).scrollTop() == $(document).height() - $(window).height()){
					//if ((offset+count) > totalSearchResults){
					if (offset > totalSearchResults){
						return false;
					}else{
						offset = offset + count;
						moreLuceneResults(offset);
					}				
				}
			}
		}); 
			
		$('.sortLucene').on('click tap', function(event){
			$(this).css('color','grey');
			$(this).attr('disabled','disabled');
			if($(this).attr('id')=="otherSort"){
				$('#relevanceSort').css('color','#005eb8').removeAttr("disabled");
				sortVal="empLastName";
			}else if($(this).attr('id')=="relevanceSort"){
				$('#otherSort').css('color','#005eb8').removeAttr("disabled");
				sortVal="relevance";
			}
			sortLuceneResults();
		});
		

		$("#filterBtn").on("click",function(){
				$( "#searchFilterDiv" ).toggle();
				$(".facet").find(".facetList:gt(4)").hide();
			
				if($('#searchFilterDiv').is(':visible') ){
					$('#div_search').find(".span12").attr("style", "width: 1350px; padding-right: 8%;");
				}else{
					$('#div_search').find(".span12").removeAttr("style");
				}
				
				//$(".more").show();
				//$(".fewer").hide();
				//$(".clearFacets").hide();
		});
			
			
		$(".more, .fewer").on("click",function(){
			$(this).parent().find(".facetList:gt(4)").toggle();
			$(this).parent().find(".more").toggle();
			$(this).parent().find(".fewer").toggle();
		});
		/*
		 * $(document.body).on("click","input:checkbox",function(){
		 * if($(this).hasClass('checkAll')){
		 * $(this).closest(".facet").find("input:checkbox").prop('checked',
		 * $(this).prop("checked")); }else{
		 * $(this).closest(".facet").find(".checkAll").prop('checked',
		 * ($(this).closest(".facet").find("input:checkbox").not(".checkAll").length ==
		 * $(this).closest(".facet").find("input:checked").not(".checkAll").length)); }
		 * });
		 */
		$(document.body).on("click","input:checkbox",function(){
			var $facetD = $(this).closest(".facet");
			if($facetD.find("input:checkbox:checked").length > 0){
				$facetD.find(".clearFacets").show();
			}else{
				$facetD.find(".clearFacets").hide();
			}
			facetSearchCall();
		});
		
		$(document.body).on("click",".clearFacets",function(){
			$(this).parent().find("input:checkbox").prop("checked", false);
			$(this).hide();
			facetSearchCall();
		});

		$("#luceneSearchClientsBtn").on('click tap', function(event){
			callSearchLucene("client");
			event.preventDefault();
		});

		/*
	    $('#advancedSearchSubmit').on('click tap',function(event){
	    	
	    	$('#advancedSearchSubmit').attr("disabled", "true");
	    	$('#advancedSearch input[type=reset]').attr("disabled", "true");
	    	
	    	var validFormArguments = false;
	    	var formElements = jQuery.makeArray($('#advancedSearch input')).concat(jQuery.makeArray($('#advancedSearch select')));
	    	// At least one field has data
	    	for(var cc=0; cc <= formElements.length; cc++){
	    		if($(formElements[cc]).val()!='' && $(formElements[cc]).val()!=undefined){
	    			validFormArguments = true;
	    			break;
	    		}else{
	    			validFormArguments = false;
	    		}
	    	}
	    	if(validFormArguments){	    		
	    		var param = $('#advancedSearch form').serialize();
	    		param = param.replace(/%2C/g,'-');
	    		spin_start('body');
	    		$.ajax({
	    			url: "../search/searchAdvanced",
	    			dataType: "json",
	    			type: "POST",
	    			data: param,
	    			success: function(data) {
	    				if(data!=null){
	    					if(data.success){
	    						if( !$('#popupSearch').is(':visible') ){
	    							toggleToSearchScreen();
	    						}
	    						populateSearchResults(data);
	    					}
	    					else{
	    						alert($("#serverErrorMsg").val());
	    					}
	    				}
	    			},
	    			error:function(xhr, ajaxOptions, thrownError){
	    				handleAjaxError(xhr, ajaxOptions, thrownError)   				
	    			},
	    			complete: function(){
	    				spin_stop('body');
	    			}
	    		});
	    	
	    	}else{
	    		// No data inputed
	    	}
	    	$('#advancedSearchSubmit').removeAttr("disabled");
	    	$('#advancedSearch input[type=reset]').removeAttr("disabled");
	    	
	    	event.preventDefault();
	    		
	    });
	    */
		$('#reset').on('click tap', function() {
		   $.ajax({
				  url: '../search/reset',
				  async: false,
				  cache: false,
				  success: function(data) {	

		   		}
			});
		   $('#searchResultsBtn').attr("disabled","disabled").css('background-color','#ccc');
		   $('#lucene_search_div option').removeAttr('selected');
		   $('#lucene_search_div select').multiselect('refresh');	   
		  // $('#advancedSearch select').multiselect('uncheckAll');
		   
	   });
		

        $(window).on('resize', function (event) {
            $('[rel="dialog-popover"]').popover('hide');
            $(".first-run-overlay").css("height",$(document).height()+"px");
        });
        
    	$(document.body).on("click","#moreElement",function(e){
    		sidr_close();
    		e.preventDefault();
    		openTypeAheadSearchResults();
    	});	
        

	});
	

});

function spin_start(target){
    spinner.spin($(target).get(0));
}
function spin_stop(target){
	spinner.stop($(target).get(0));
}
function handleAjaxError(xhr, ajaxOptions, thrownError){
	if (xhr.status == 0 ){
		// alert($("#sessionTimeOutMsg").val());
    	location.reload();    	
    } else {    	
    	alert($("#serverErrorMsg").val() + ": " + xhr.statusText);
    }
}
function showNoPhoto(divName, className){ 
	$('#'+divName).text('No Photo');
	$('#'+divName).addClass(className);
}
function sidr_open(){
	$('#responsive-menu-button').addClass('togglemenu');
	$('body').addClass('sidr-open');
	$('.sidr').addClass('right');
	$('.sidr').show();
	$('.sidr').scrollTop(0);
}
function sidr_close(){
	if( $('#responsive-menu-button' ).hasClass('togglemenu')){
		$('#responsive-menu-button').removeClass('togglemenu');
		$('body').removeClass('sidr-open');
		$('.sidr').removeClass('right');
		$('.sidr').hide();
	}
}
function createHref(url,label){
	var link = "";
	if(label != null && label != '' ){
		link = "<a href='" +url+ "'>" + label + "</a>";
	}
	return link;
}
function getDocumentURL(){
	var url = document.URL;
	var result = new documentUrl();
	if (url.indexOf('#')>0) {
		result.url = url.substr(0, url.indexOf('#'));
		result.param = url.substr(url.indexOf('#'), url.length);
	} else {
		result.url = url;
		result.param = null;
	}
	return result;
}
function documentUrl(url, param) {
    this.url = url;
    this.param = param;
} 
function validnull (value){
	if (value != null){
		return value;
	} else {
		return '';
	}
}
function toggleAccordionToggle(event) {
    var $target = $(event.target);
    var $toggle = $target.parent('.accordion-group').find('.accordion-toggle');
    if (event.type === 'show' || (event.type === 'load' && $target.hasClass('in'))) {
      $toggle.addClass('in');
    } else if (event.type === 'hide') {
      $toggle.removeClass('in');
    }
  }

// UTF definitions on the last line are there to align with Oracles CONVERT
// US7ASCII missing characters
function replaceSpecialChars(str){
	   str = encodeURIComponent(str.toLowerCase());
	   str = escape(str);
	   str=str.replace(/%27/g,'[$27]');
 return str;
}

function openTypeAheadSearchResults(){
	//$("form.navbar-search").removeClass("open");
	toggleToSearchResults();
	if(typeaheadSelect!=null){
		populateTypeSearchList();
	}
}
/*
 * function toggleToSearchScreen(){ window.location.href =
 * document.URL.replace("#search","") + '#search'; $("#container").hide('slow');
 * $("#div_profile").hide('slow'); $("#div_AdvSearch").hide('slow');
 * 
 * $("#div_SearchResults").show(); $("#tab_search_results").fadeIn('slow');
 * blockSearch(); }
 */

function initMultiselects(){
	
    $('#businessSelect').multiselect({
		enableCaseInsensitiveFiltering: true,		// enableFiltering: true,
		// filterBehavior: 'text',
		buttonWidth:false,
		maxHeight: 200,
		includeSelectAllOption: true,
		numberDisplayed: 2,
		nonSelectedText : 'Any',
		onDropdownHidden : function(event){
			if($('select[name=business]').val()!=null){
				
				spin_start("#lucene_search_div");	
				$("#subBusinessSelect").multiselect("destroy");
				$('#subBusinessSelect').multiselect({
					enableCaseInsensitiveFiltering: true,		// enableFiltering:
																// true,
					// filterBehavior: 'text',
					buttonWidth:false,
					maxHeight: 200,
					includeSelectAllOption: true,				
					includeSelectAllDivider: true,
					numberDisplayed: 3,
					nonSelectedText : 'Select Options'
				});
				loadSubBusinessCatalog($('select[name=business]'));
				$('select[name=subBusiness]').multiselect("enable");	
			}
			else{
				$('select[name=subBusiness] option').removeAttr('selected');
				$('select[name=subBusiness]').multiselect("refresh");
				$("#subBusinessSelect").multiselect("destroy");
				$('#subBusinessSelect').multiselect({
					enableCaseInsensitiveFiltering: true,		// enableFiltering:
																// true,
					// filterBehavior: 'text',
					buttonWidth:false,
					maxHeight: 200,
					includeSelectAllOption: true,
					numberDisplayed: 3,
					nonSelectedText : 'Please choose Business Segment first'
				});
				$('select[name=subBusiness]').multiselect("disable");
			}
		}
	});
    
    $('#functionSelect').multiselect({
		enableCaseInsensitiveFiltering: true,		// enableFiltering: true,
		// filterBehavior: 'text',
		buttonWidth:false,
		maxHeight: 200,
		includeSelectAllOption: true,
		numberDisplayed: 2,
		nonSelectedText : 'Any',
		onDropdownHidden : function(event){
			if($('select[name=function]').val()!=null){
				
				spin_start("#lucene_search_div");
				$("#jobFamilySelect").multiselect("destroy");
				$('#jobFamilySelect').multiselect({
					enableCaseInsensitiveFiltering: true,		// enableFiltering:
																// true,
					// filterBehavior: 'text',
					buttonWidth:false,
					maxHeight: 200,
					includeSelectAllOption: true,				
					includeSelectAllDivider: true,
					numberDisplayed: 3,
					nonSelectedText : 'Select Options'
				});
				loadJobFamilyCatalog($('select[name=function]'));
				$('select[name=jobFamily]').multiselect("enable");
				
					
			}
			else{
				$('select[name=jobFamily] option').removeAttr('selected');
				$('select[name=jobFamily]').multiselect("refresh");
				$("#jobFamilySelect").multiselect("destroy");
				$('#jobFamilySelect').multiselect({
					enableCaseInsensitiveFiltering: true,		// enableFiltering:
																// true,
					// filterBehavior: 'text',
					buttonWidth:false,
					maxHeight: 200,
					includeSelectAllOption: true,
					numberDisplayed: 3,
					nonSelectedText : 'Please choose Function first'
				});
				$('select[name=jobFamily]').multiselect("disable");
			}
		}
	});
    
    $('#regionSelect').multiselect({
        enableCaseInsensitiveFiltering: true,           // enableFiltering:
														// true,
        // filterBehavior: 'text',
        buttonWidth:false,
        maxHeight: 200,
        includeSelectAllOption: true,
        numberDisplayed: 2,
        nonSelectedText : 'Any',
        onDropdownHidden : function(event){               
               if($('select[name=region]').val()!=null){
                     
                     spin_start("#lucene_search_div");     
                     $("#countrySelect").multiselect("destroy");
                     $('#countrySelect').multiselect({
                            enableCaseInsensitiveFiltering: true,           // enableFiltering:
																			// true,
                            // filterBehavior: 'text',
                            buttonWidth:false,
                            maxHeight: 200,
                            includeSelectAllOption: true,                          
                            includeSelectAllDivider: true,
                            numberDisplayed: 3,
                            nonSelectedText : 'Select Options'
                     });
                     loadCountryCatalog($('select[name=region]'),'region');
                     $('select[name=country]').multiselect("enable");                                  
               }else{
            	   spin_start("#lucene_search_div");     
                   $("#countrySelect").multiselect("destroy");
                   $('#countrySelect').multiselect({
                          enableCaseInsensitiveFiltering: true,           // enableFiltering:
																			// true,
                          // filterBehavior: 'text',
                          buttonWidth:false,
                          maxHeight: 200,
                          includeSelectAllOption: true,                          
                          includeSelectAllDivider: true,
                          numberDisplayed: 3,
                          nonSelectedText : 'Select Options'
                   });
                   loadCountryCatalog($('select[name=country]'),'country');
                   $('select[name=country]').multiselect("enable");
               }
        }
    	});

    
    $('#leadershipProgramSelect').multiselect({
    	enableCaseInsensitiveFiltering: true,
    	buttonWidth:false,
		maxHeight: 200,
		includeSelectAllOption: true,
		numberDisplayed: 3,
		nonSelectedText : 'Any',
		onDropdownHidden : function(event, ui){
			
			if($('select[name=leadershipProgram]').val()!=null){
				// $('select[name=leadershipProgramType]').removeAttr("disabled");
				$('input[name=leadershipProgramType]').removeAttr('disabled');
			}
			else{
				//$('input[name=leadershipProgramType]').prop("checked",false);
				$('input[name=leadershipProgramType]').first().prop("checked",true);
				//$('select[name=leadershipProgramType]').attr("disabled","disabled");
				$('input[name=leadershipProgramType]').attr('disabled','disabled'); 
			}
		
		}
    });

		$('#regionSelect, #countrySelect, #leadershipProgramSelect, #bandSelect, #ifgSelect').multiselect({
			enableCaseInsensitiveFiltering: true,		// enableFiltering:
														// true,
			filterBehavior: 'text',
			buttonWidth:false,
			maxHeight: 200,
			includeSelectAllOption: true,
			includeSelectAllDivider: true,
			numberDisplayed: 3,
			nonSelectedText : 'Any'			
		});
		
		$('#businessSelect, #functionSelect, #regionSelect, #countrySelect, #leadershipProgramSelect, #bandSelect, #ifgSelect').multiselect('rebuild');		
		
		$('#subBusinessSelect').multiselect({
			enableCaseInsensitiveFiltering: true,
			filterBehavior: 'text',
			nonSelectedText: 'Please choose Business Segment first',
			buttonWidth: "auto",
			numberDisplayed: 3					// selectedList: 3
		});
		
		$('#jobFamilySelect').multiselect({
			enableCaseInsensitiveFiltering: true,
			filterBehavior: 'text',
			nonSelectedText: 'Please choose Function first',
			buttonWidth: "auto",
			numberDisplayed: 3					// selectedList: 3
		});	
		
		/*
		$('#leadershipProgramTypeSelect').multiselect({
			nonSelectedText: 'N/A',
			multiple: false,
			buttonClass: 'multi_lpt btn',
			buttonWidth: "auto"
		});
		$('#leadershipProgramTypeSelect').multiselect("disable");
		*/
}

function toggleToSearchResults(){
	$("#container ul.nav").hide();
	$(".hideOnCollapse").hide();
	$("#div_profile").hide();
	//$("#div_advSearch").hide();
	$("#div_search").show();
	$("#div_luceneSearch").hide();
	$("#lucene_search_div").hide();
}

function toggleToLuceneSearchScreen(){
	spin_start('body');
	// window.location.href = document.URL.replace("/search","") + '/search';
	$("#container ul.nav").hide();
	$(".hideOnCollapse").hide();
	$("#div_profile").hide();
	//$("#div_advSearch").hide();
	$("#div_search").hide();
	$("#div_luceneSearch").show();
	$("#lucene_search_div").show();
	initSearchCatalogs();
    loadSearchCatalogs();
	// blockSearch();
    spin_stop("body");
}
/**
 * 
 */
/*
function toggleToSearchScreen(){
	// window.location.href = document.URL.replace("#search","") + '#search';
	$("#container ul.nav").hide();
	$(".hideOnCollapse").hide();
	$("#div_profile").hide();
	$("#div_advSearch").hide();
	$("#div_luceneSearch").hide();
	$("#lucene_search_div").hide();
	$("#div_search").show();
	$("#popupSearch").show();
	// blockSearch();
}
*/
/*
function keyDownEventSso(e){		
        var key = e.charCode || e.keyCode || 0;
        // allow backspace, tab, delete, arrows, numbers and keypad numbers ONLY
        return (
            key == 8 || 
            key == 9 ||
            key == 46 ||
            (key >= 37 && key <= 40) ||
            (key >= 48 && key <= 57) ||
            (key >= 96 && key <= 105));	    
}
*/

function loadSubBusinessCatalog(selectElement){
	// alert("select Element :" +selectElement.val());
	// Prevent NPE
	if(selectElement.data("selectedOptions") == null || selectElement.data("selectedOptions") == undefined){
		// alert("selectElement.data(selectedOptions) is undefined");
		selectElement.data("selectedOptions", []);
	}
	
	// Check for change
	if(selectElement.val()!= null && selectElement.val().join("|") != selectElement.data("selectedOptions")){
		// Store new state for future change check
		selectElement.data("selectedOptions", selectElement.val().join("|"));
		
		// *************
		// Load SubBusinesses
		//$("#advancedSearch").addClass("busy");
				
		// Clear Options if any
		/*
		 * var subbusinessSelectElements =
		 * $('select[name=subBusiness]').children();
		 * if(subbusinessSelectElements.length>0){ var elementNumber =
		 * subbusinessSelectElements.length; for(var cc=0; cc < elementNumber;
		 * cc++){ var lastElementIndex =
		 * $('select[name=subBusiness]').children().length - 1;
		 * $(subbusinessSelectElements[ lastElementIndex ]).remove(); } }
		 */
		var subbusinessSelectElements = $('select[name=subBusiness]').val();
		$('select[name=subBusiness]').html("");
		renderBusinessDropdownCatalogs(subbusinessSelectElements);
		// $('select[name=subBusiness]').multiselect("refresh");
		
	}
	spin_stop("#lucene_search_div");
}

function loadJobFamilyCatalog(selectElement){
	// alert("select Element :" +selectElement.val());
	// Prevent NPE
	if(selectElement.data("selectedOptions") == null || selectElement.data("selectedOptions") == undefined){
		// alert("selectElement.data(selectedOptions) is undefined");
		selectElement.data("selectedOptions", []);
	}
	
	// Check for change
	if(selectElement.val()!= null && selectElement.val().join("|") != selectElement.data("selectedOptions")){
		// Store new state for future change check
		selectElement.data("selectedOptions", selectElement.val().join("|"));
		
		// *************
		// Load SubBusinesses
		
		/*
		 * var jobFamilySelectElements = $('select[name=jobFamily]').children();
		 * //Clear Options if any if(jobFamilySelectElements.length>0){ var
		 * elementNumber = jobFamilySelectElements.length; for(var cc=0; cc <
		 * elementNumber; cc++){ var lastElementIndex =
		 * $('select[name=jobFamily]').children().length - 1;
		 * $(jobFamilySelectElements[ lastElementIndex ]).remove(); } }
		 */
		var jobFamilySelectElements = $('select[name=jobFamily]').val();
		$('select[name=jobFamily]').html("");
		renderFunctionDropdownCatalogs(jobFamilySelectElements);
		// $('select[name=subBusiness]').multiselect("refresh");
		
	}
	spin_stop("#lucene_search_div");
}

function loadCountryCatalog(selectElement, element){
    // alert("select Element :" +selectElement.val());
    // Prevent NPE
    if(selectElement.data("selectedOptions") == null || selectElement.data("selectedOptions") == undefined){
           // alert("selectElement.data(selectedOptions) is undefined");
           selectElement.data("selectedOptions", []);
    }
    
    // Check for change
    if(selectElement.val()!= null && selectElement.val().join("|") != selectElement.data("selectedOptions")){
           // Store new state for future change check
           selectElement.data("selectedOptions", selectElement.val().join("|"));
	if(element == 'region'){
           
           // *************
           // Load SubBusinesses
           /*
			 * var countrySelectElements = $('select[name=country]').children();
			 * //Clear Options if any if(countrySelectElements.length>0){ var
			 * elementNumber = countrySelectElements.length; for(var cc=0; cc <
			 * elementNumber; cc++){ var lastElementIndex =
			 * $('select[name=country]').children().length - 1;
			 * $(countrySelectElements[ lastElementIndex ]).remove(); } }
			 */
           var countrySelectElements = $('select[name=country]').val();
           $('select[name=country]').html("");
           renderRegionDropdownCatalogs(countrySelectElements);
           // $('select[name=subBusiness]').multiselect("refresh"); 	
	}
	else{

        /*
		 * var countrySelectElements = $('select[name=country]').children();
		 * //Clear Options if any if(countrySelectElements.length>0){ var
		 * elementNumber = countrySelectElements.length; for(var cc=0; cc <
		 * elementNumber; cc++){ var lastElementIndex =
		 * $('select[name=country]').children().length - 1;
		 * $(countrySelectElements[ lastElementIndex ]).remove(); } }
		 */
        $('select[name=country]').html("");
        loadCatalog('search/country', $('select[name=country]'));
        // $('select[name=country]').append(optValues);
        $('select[name=country]').multiselect("rebuild");     

	}
    }
	spin_stop("#lucene_search_div");
}

function renderBusinessDropdownCatalogs(selectedVal){
	
	var optValues = '';
	for(var cc = 0; cc < $('select[name=business] option:selected').length + 1; cc++){
		if(cc == $('select[name=business] option:selected').length){
			break;
		}else{
		var business = $('select[name=business] option:selected')[cc];
		
		optValues += "<optgroup label='"+$(business).val()+"'>";
		optValues += loadCatalog('search/business?query='+encodeURIComponent($(business).val()), null);
		
		optValues += "</optgroup>";
		}
	}
	$('select[name=subBusiness]').append(optValues);
	$('select[name=subBusiness]').multiselect("rebuild");
	if(selectedVal!=null){
	selectOption($('select[name=subBusiness]'), selectedVal);
	}
}

function renderFunctionDropdownCatalogs(selectedVal){
	
	var optValues = '';
	for(var cc = 0; cc < $('select[name=function] option:selected').length + 1; cc++){
		if(cc == $('select[name=function] option:selected').length){
			break;
		}else{
		var functionn = $('select[name=function] option:selected')[cc];
		
		optValues += "<optgroup label='"+$(functionn).val()+"'>";
		optValues += loadCatalog('search/function?query='+encodeURIComponent($(functionn).val()), null);
		
		optValues += "</optgroup>";
		}
	}
	$('select[name=jobFamily]').append(optValues);
	$('select[name=jobFamily]').multiselect("rebuild");
	if(selectedVal!=null){
		selectOption($('select[name=jobFamily]'), selectedVal);
	}
}

function renderRegionDropdownCatalogs(selectedVal){
    
    var optValues = '';
    for(var cc = 0; cc < $('select[name=region] option:selected').length + 1; cc++){
           if(cc == $('select[name=region] option:selected').length){
                  break;
           }else{
           var region = $('select[name=region] option:selected')[cc];
           
           optValues += "<optgroup label='"+$(region).val()+"'>";
           optValues += loadCatalog('search/country?query='+encodeURIComponent($(region).val()), null);
           
           optValues += "</optgroup>";
           }
    }
    $('select[name=country]').append(optValues);
    $('select[name=country]').multiselect("rebuild");
	if(selectedVal!=null){
		selectOption($('select[name=country]'), selectedVal);
		}
}

function loadSearchCatalogs(event){
	if(!dialogInitialized){
	
		for(var cc = 0; cc < catalogService.length; cc++){
			loadCatalog(catalogService[cc], selectElements[cc]);
		}
		
		setSearchParameters(searchParameters);
		
		initMultiselects();
	}
	// $("#advancedSearch").unblock();
	dialogInitialized = true;
}

function loadCatalog(catalogService, selectElement){

	var optionHtml = "";
	
	var async = false;
	
	$.ajax({
		url: "../"+catalogService,
		dataType: "json",
		async: async,
		success: function(data) {
			if(data!=null){
				
				
				if(data.success){			
					
					if(selectElement != null){
					
						$.each(data.catalog.list, function(key, value) {   
							selectElement
						         .append($("<option></option>")
						         .attr("value",value)
						         .text(value)); 
						});
					}else{
						
						for(var cc=0; cc < data.catalog.list.length; cc++){
							optionHtml += "<option>"+data.catalog.list[cc]+"</option>";
						}
						
					}
					
					
				}
				else{
					// alert($("#serverErrorMsg").val());
					$("#unableToLoad").html("Advanced Search Catalog");
					$(".alert-box").show();
				}
			} // spin_stop("#lucene_search_div");
		},
		error:function(xhr, ajaxOptions, thrownError){
			handleAjaxError(xhr, ajaxOptions, thrownError);
		}
	});
	
	return optionHtml;
}

function initSearchCatalogs(){
	
	if(!dialogInitialized){
		//initMultiselects();
		
		//bandVisibility = getBandVisibility();	
		searchParameters = getSearchParameters("advancedSearch");
		
		// Show hide band
		if(bandVisibility){
			catalogService[catalogService.length] = "search/band";
			selectElements[selectElements.length] = $('select[name=band]');
		}else{
			$('#bandSearch').hide();
			//$('#bandWarning').hide();
		}
	}
}

function setSearchParameters(params){
	  
	   if(params!=null){
		   //

		   if(hasValue(params.leadershipProgram)){
			   // alert("leadershipProgramType");
			   selectOption($('select[name=leadershipProgram]'), params.leadershipProgram);
			   $('input[name=leadershipProgramType]').removeAttr('disabled');
			   if(hasValue(params.leadershipProgramType)){				
				   selectOptionRadio($('div#leadershipProgramTypeSelect'), params.leadershipProgramType);
			   } 
		   }
// if(hasValue(params.country)){
// selectOption($('select[name=country]'), params.country);
// }
// if(hasValue(params.region)){
// selectOption($('select[name=region]'), params.region);
// }
// if(hasValue(params["function"])){
// selectOption($('select[name=function]'), params["function"]);
// }
		   if(bandVisibility && hasValue(params.band)){
			   selectOption($('select[name=band]'), params.band);
		   }
		   if(hasValue(params.business)){
			   
			   selectOption($('select[name=business]'), params.business);
			   loadSubBusinessCatalog($('select[name=business]'));
				$("#subBusinessSelect").multiselect("destroy");
				$('#subBusinessSelect').multiselect({
					enableCaseInsensitiveFiltering: true,		// enableFiltering:
																// true,
					buttonWidth:false,
					maxHeight: 200,
					includeSelectAllOption: true,
					numberDisplayed: 2,
					nonSelectedText : 'Select Options'
				});
				$('select[name=subBusiness]').multiselect('enable');
				
			   if(hasValue(params.subBusiness)){
				   selectOption($('select[name=subBusiness]'), params.subBusiness);
			   }
		   }

		   
		   if(hasValue(params["function"])){
			   
			   selectOption($('select[name=function]'), params["function"]);
			   loadJobFamilyCatalog($('select[name=function]'));
				 $("#jobFamilySelect").multiselect("destroy");
				 $('#jobFamilySelect').multiselect({
				 enableCaseInsensitiveFiltering: true, // enableFiltering:
														// true,
				 buttonWidth:false,
				 maxHeight: 200,
				 includeSelectAllOption: true,
				 numberDisplayed: 2,
				 nonSelectedText : 'Select Options'
				 });
				 $('select[name=jobFamily]').multiselect('enable');
				   if(hasValue(params.jobFamily)){
				   selectOption($('select[name=jobFamily]'), params.jobFamily);
				 }
			   
		   }
		   
		   if(hasValue(params.region)){		                           
	          selectOption($('select[name=region]'), params["region"]);
	          loadCountryCatalog($('select[name=region]'),'region');
	                           
	          $("#countrySelect").multiselect("destroy");
	          $('#countrySelect').multiselect({
	                 enableCaseInsensitiveFiltering: true,           // enableFiltering:
																		// true,
	                 buttonWidth:false,
	                 maxHeight: 200,
	                 includeSelectAllOption: true,
	                 numberDisplayed: 2,
	                 nonSelectedText : 'Select Options'
	          });
	          $('select[name=country]').multiselect('enable');
	          if(hasValue(params.country)){
	                 selectOption($('select[name=country]'), params.country);
	          }
		   }else{
			   if(hasValue(params.country)){
				   selectOption($('select[name=country]'), params.country);
		   	   }
		   }
		   	  
		   if(hasValue(params.ifg)){
			   selectOption($('select[name=ifg]'), params.ifg);
		   }
		   
		   if(hasValue(params.ssoName)){
			   $('#lucene_search_div input[name="ssoName"]').val( params.ssoName );
		   }
		   
		   if(hasValue(params.title)){
			   $('#lucene_search_div input[name="title"]').val( params.title );
		   }
		   
		   if(hasValue(params.emailPhone)){
			   $('#lucene_search_div input[name="emailPhone"]').val( params.emailPhone );
		   }

		   if(hasValue(params.managerDetails)){
			   $('#lucene_search_div input[name="managerDetails"]').val( params.managerDetails );
		   }
		   
		   if(hasValue(params.organization)){
			   $('#lucene_search_div input[name="organization"]').val( params.organization );
		   }
		   
		   if(hasValue(params.location)){
			   $('#lucene_search_div input[name="location"]').val( params.location );
		   }
		   
		   if(hasValue(params.workHistory)){
			   $('#lucene_search_div input[name="workHistory"]').val( params.workHistory );
		   }
		   
		   if(hasValue(params.eduTrng)){
			   $('#lucene_search_div input[name="eduTrng"]').val( params.eduTrng );
		   }
	   }
	   
}

function getSearchParameters(param){
	   var parametersL = null;
	   
	   $.ajax({
			  url: '../search/parameters'+'?type='+param,
			  async: false,
			  cache: false,
			  success: function(data) {
					   		
				//if(data!=null && data.success){
				if(data!=null){
					parametersL = data;
				}
			  },
			error:function(xhr, ajaxOptions, thrownError){
				handleAjaxError(xhr, ajaxOptions, thrownError)   				
			}
		});	
	   
	   return parametersL;
}
function hasValue(value){
	   var hasValue = false;
	   
	   if(value!=null && value != "" && value != undefined){
		   if( $.isArray(value)){
			   if(value.length > 0){
				   hasValue = true;
			   }else{
				   hasValue = false;
			   }
		   }else{
			   hasValue = true;
		   }
	   }
	   return hasValue;
}
function selectOptionRadio(input, inputValue){
	input.find('input').each(function(index, value){
		   value = $(value);
		   if(value.val() == UTF8.decode(inputValue)){				   
			   value.prop("checked", true);
		   }
	   });
}
function selectOption(select, optionValues){
	   for(var cc = 0; cc < optionValues.length; cc++){
		   
		   
		   
		   select.find('option').each(function(index, value){
			   value = $(value);
			   if(value.val() == UTF8.decode(optionValues[cc])){				   
				   value.attr("selected", "selected");
			   }
		   });
		   
		   $('#lucene_search_div select').multiselect('refresh');
		   
		   
	   }
}
function sidrCollapse(){
	 if ($(window).width() >= 300 && $(window).width() <= 979) {
		    var $navbar = $( '.navbar-inner > .container', this.element );
		    var $items = $navbar.children('.pull-right').children(':not(.btn[data-toggle="collapse"])');
		    var $target = $( '.primary-navbar > .container > .responsive-elements', this.element );
		    if ( !$target.size() ) {
			    $( '.primary-navbar > .container', this.element ).prepend( $( '<div class="responsive-elements"></div>' ) );
			    $target = $( '.primary-navbar > .container > .responsive-elements', this.element );
		    }
		    $target.append($items);
		    if(!$("#search-div-col").hasClass("menu-collapsed")){
		    	$("#search-div-col").show();
		    	$("#search-div-col").addClass("menu-collapsed")
			    $("#search-div-col").html($("#search-div").html());
			    $("#search-div").children().remove();
			    $("#search-div").hide();
			    $("#header-buttons-col").show();
		    	$("#header-buttons-col").html($("#header-buttons").html());
		    	$("#header-buttons").children().remove();
			    $("#header-buttons").hide();
		    }
	 }else {
			$("#search-div").show();
			$("#header-buttons").show();
			if($("#search-div-col").hasClass("menu-collapsed")){
		    $("#search-div").html($("#search-div-col").html());
		    $("#header-buttons").html($("#header-buttons-col").html());
			}
			$("#search-div-col").removeClass("menu-collapsed");
		    $("#search-div-col").children().remove();
		    $("#search-div-col").hide();
		    $("#header-buttons-col").children().remove();		    
		    $("#header-buttons-col").hide();
	 }
}

function populateLuceneResults(data){
	if(data !=null){
		$('#resultContent table').html('');
		$('#resultContent table').html(createSearchResultHtml(data));
	}
}

function appendLuceneResults(data){
	if(data !=null){
		$('#resultContent table').append(createSearchResultHtml(data));
	}
}

function typeaheadSearch(){
	/*
	 * $(document.body).on("blur","#search",function(e){
	 * $("ul.typeahead").hide(); });
	 * $(document.body).on("focus","#search",function(e){ if($("ul.typeahead
	 * li").size()>0){ $("ul.typeahead").show(); } });
	 */
	$(document.body).on("keypress keydown keyup blur focus","#search",function(e){
		var key = (e.keyCode ? e.keyCode : e.which);
		if(key == 13 ) {
			//sidr_close();		
			openTypeAheadSearchResults();
			e.preventDefault();
		// }else if(key == 8 || key == 9 || key == 46 ){
			
		}else{
			setTimeout(function(){
			// var c = String.fromCharCode(key);
			var typeaheadSelectnew = $("#search").val();
			if(typeaheadSelect != typeaheadSelectnew){
			typeaheadSelect = typeaheadSelectnew;
			var length = (typeaheadSelect==null||typeaheadSelect==undefined||typeaheadSelect=="")?0:typeaheadSelect.length;
			if(length>2){
				counter++;
			$.ajax({
				url: "../search/searchtypeahead?query=" + replaceSpecialChars(typeaheadSelect) +"&c="+counter,
				// data: {'query' : replaceSpecialChars(request.term)},
				dataType: "json",
				success: function(data) {
					if(data!=null && data.counter == counter){
						if(data.success){							
							if(data.autoComplete!= null){
								var content = "";
								$.each( data.autoComplete.rows, function(index, item){
									content += '<li data-value="'+item.label+'" class=""><a href="'+item.value+'">'+item.label+'</a></li>';
								});
								content += '<li id="moreElement" data-value="More..." class=""><a href="#"><strong>More...</strong></a></li>';								
								$("ul.typeahead").html(content);								
							}else{
								var errorMessage = (data.errorMessage != null && data.errorMessage != undefined)? data.errorMessage : ERROR_MSG; 
								// alert(errorMessage);
								// if($("ul.typeahead li").size()<1){
								// $("ul.typeahead").hide();
								// }
							}						 
						}
					}
				},
				error:function(xhr, ajaxOptions, thrownError){
					// loaderToggle("#imgSearch", 'stop');
					handleAjaxError(xhr, ajaxOptions, thrownError);
				}
			});
			
		}else{
			// $("ul.typeahead").hide();
		}
			}
	},0);
		}
		
				
	});
}

function createSearchResultHtml(data){
	var searchTable = "";
	if(data.length != 0){	
		for(var ii = 0; ii < data.length; ii++){
	
			searchTable += '<tr style="height:100px;word-wrap: break-word;">';
			searchTable += '<td><div id="div_photoSearch_'+offset+'_'+ii+'"><img class="photoSearch" src="'+profilePhoto+validnull(data[ii].sso)+'.jpg" onerror="this.style.visibility=&#39;hidden&#39;; showNoPhoto(&#39;div_photoSearch_'+offset+'_'+ii+'&#39;,&#39;div_photoSearch_'+offset+'_'+ii+'&#39;);"/></div></td>';
			searchTable += '<td style="width: 300px;padding-right: 5px;height:inherit;">';
			searchTable += '<div style="height: 20px; padding-top: 10px; padding-bottom: 10px;">';
			searchTable += '<a class="btn btn-link" style="margin-bottom: 0px;width:300px;text-transform: capitalize" href="'+ validnull(data[ii].sso) +'">' + capitalize(validnull(data[ii].empLastName)) +", "+capitalize(validnull(data[ii].empFirstName)) + " ("+validnull(data[ii].sso) +")"+'</a>';
			searchTable += '</div>';
			searchTable += '<div style="height: 50px; width: 230px; padding-bottom: 10px;">';
			searchTable += validnull(data[ii].business) +", "+validnull(data[ii].ifg) +", "+validnull(data[ii].subBusiness);
			searchTable += '</div>';
			searchTable += '</td>';
			searchTable += '<td style="width:140px;padding-right: 10px;">';
			searchTable += '<div style="height: 50px; padding-top: 10px; padding-bottom: 10px;">';
			searchTable += '<div >Title</div>';
			searchTable += '<hr />';
			searchTable += '<div style="width:140px;">'+ validnull(data[ii].title) +'</div>';
			searchTable += '</div>';
			searchTable += '</td>';
			searchTable += '<td style="width: 80px;padding-right: 10px;">';
			searchTable += '<div style="height: 50px; padding-top: 10px; padding-bottom: 10px;">';
			searchTable += '<div width: 80px;>Function</div>';
			searchTable += '<hr />';
			searchTable += '<div style="width: 80px;word-wrap: break-word;">'+validnull(data[ii].func) +'</div>';
			searchTable += '</div>';
			searchTable += '</td>';
			searchTable += '<td style="width: 80px;padding-right: 10px;">';
			searchTable += '<div style="height: 50px; padding-top: 10px; padding-bottom: 10px;">';
			searchTable += '<div >Manager</div>';
			searchTable += '<hr />';
			searchTable += '<div style="width: 80px;"><a href ="' + validnull(data[ii].ohMgrSso) +'" style="text-transform: capitalize">' + capitalize(validnull(data[ii].ohMgrFirstName)) + '<br>' +capitalize(validnull(data[ii].ohMgrLastName)) +'</a></div>';
			searchTable += '</div>';
			searchTable += '</td>';
			searchTable += '<td style="width: 320px;">';
			searchTable += '<div style="height: 50px; width: 320px; padding-top: 10px;padding-bottom: 10px;">';
			searchTable += '<div >Org Hierarchy</div>';
			searchTable += '<hr />';
			searchTable += '<div style="height: 35px; width: 100px;float:left"><a href ="' + validnull(data[ii].ohMgrSso1) +'">' + validnull(data[ii].ohMgrFirstName1) + '<br> ' +validnull(data[ii].ohMgrLastName1) +'</a></div>';
			searchTable += '<div style="height: 35px; width: 100px;float:left; padding-left: 5px; padding-right: 5px;"><a href ="' + validnull(data[ii].ohMgrSso2) +'">' + validnull(data[ii].ohMgrFirstName2) + ' <br>' +validnull(data[ii].ohMgrLastName2) +'</a></div> ';
			searchTable += '<div style="height: 35px; width: 100px;float:left;"><a href ="' + validnull(data[ii].ohMgrSso3) +'">' + validnull(data[ii].ohMgrFirstName3) + ' <br>' +validnull(data[ii].ohMgrLastName3) +'</a></div>';
			searchTable += '</div>';
			searchTable += '</td>';
			searchTable += '</tr>';	
		
		}
	}
	return searchTable;
	
}

function populateTypeSearchList(){
	spin_start('body');
	enableSearchBtn();
	$('#modifySearchLink').hide();
	$('#resultContent table').html('');
	resetSortLink();
	$.ajax({
		  url: "../search/typeaheadsearchresults?query=" +replaceSpecialChars(typeaheadSelect),
		  success: function(data) {
			  $('#resultsLabel').html(data.resultLabel);
			  $('#resultContent table').html('');
			  if(data!=null && data.success){
					if(data.type=='TYPEAHEAD'){
						$('#modifySearchLink').hide();
					}
					//$('.sortLucene').removeAttr('disabled');
					totalSearchResults = data.total;
					populateLuceneResults(data.searchList);
					populateFacets(data.facetList);
					toggleToSearchResults();
				}
		  	},
			error:function(xhr, ajaxOptions, thrownError){
				handleAjaxError(xhr, ajaxOptions, thrownError)   				
			},
			complete: function(){
				spin_stop('body');
			}
	});		
	
}

function callSearchLucene(type){
	searchHist = false;
	spin_start('body');
	var param= $("#lucene_search_div form").serialize();
	resetSortLink();
	var searchUrl = "";
	if(type=="all"){
		searchUrl = "../search/searchLuceneAll";
	}else if(type=="client"){
		searchUrl = "../search/searchLuceneClients";
	}else if(type=="history"){
		searchUrl = "../search/searchLucene?history=true";
	}
	$.ajax({
		url: searchUrl,
		dataType: "json",
		type: "POST",
		data: param,
		success: function(data) {
			if(data.type=='ADVANCED'){
				$('#modifySearchLink').show();
			}else if(data.type=='TYPEAHEAD'){
				$('#modifySearchLink').hide();
			}
			enableSearchBtn();
			$('#resultsLabel').html(data.resultLabel);
			if(data!=null){
				//$('.sortLucene').removeAttr('disabled');
				totalSearchResults = data.total;
				populateLuceneResults(data.searchList);
				populateFacets(data.facetList);
				toggleToSearchResults();
				initFacetSearch();
			}
		},
		error:function(xhr, ajaxOptions, thrownError){
			handleAjaxError(xhr, ajaxOptions, thrownError)   				
		},
		complete: function(){
			spin_stop('body');
		}
	});
}

function sortLuceneResults(){
	spin_start('body');
	resetOffset();
	$.ajax({
		url: "../search/searchLucene"+ (sortVal!=""?"?sortBy="+sortVal:""),
		dataType: "json",
		type:'POST',
	   success: function(data) {
			// $('#resultsLabel').html(data.resultLabel);
			if(data!=null){
				populateLuceneResults(data.searchList);
				toggleToSearchResults();
			}			
		},
		error:function(xhr, ajaxOptions, thrownError){
			handleAjaxError(xhr, ajaxOptions, thrownError)   				
		},
		complete: function(){
			spin_stop('body');
		}
	});
}

function moreLuceneResults(offset){
	//spin_start('.searchInfiniteSpin');
	$.ajax({
		url: "../search/searchLucene"+ (sortVal!=""?"?sortBy="+sortVal:""),
		dataType: "json",
		type:'POST',
		data: ({
			"offset": offset,	
			"more" : true
	    }),
		success: function(data) {
			// $('#resultsLabel').html(data.resultLabel);
			if(data!=null){
				appendLuceneResults(data.searchList);
				toggleToSearchResults();
			}
		},
		error:function(xhr, ajaxOptions, thrownError){
			handleAjaxError(xhr, ajaxOptions, thrownError)   				
		},
		complete: function(){
			//spin_stop('.searchInfiniteSpin');
		}
	});
}

function facetSearchCall(){	
	var param = $('#div_search form').serialize();
	var searchUrl = "../search/searchLucene?facet=true" + (sortVal!=""?"&sortBy="+sortVal:"");
	resetOffset();
	$.ajax({
		url: searchUrl,
		dataType: "json",
		type: "POST",
		data: param,
		success: function(data) {
			if(data.type=='ADVANCED'){
				$('#modifySearchLink').show();
			}
			enableSearchBtn();
			$('#resultsLabel').html(data.resultLabel);
			if(data != null){
				$('.sortLucene').removeAttr('disabled');
				totalSearchResults = data.total;
				populateLuceneResults(data.searchList);
				toggleToSearchResults();
			}
		},
		error:function(xhr, ajaxOptions, thrownError){
			handleAjaxError(xhr, ajaxOptions, thrownError)   				
		},
		complete: function(){
			spin_stop('body');
		}
	});
}

function capitalize(str){
	str = str.toLowerCase();
	return str;
}

function resetOffset(){
	offset = 0;
}

function resetSortLink(){
	sortVal = "";
	$('#relevanceSort').css('color','grey').attr('disabled','disabled');
	$('#otherSort').css('color','#005eb8').removeAttr("disabled");
}

function enableSearchBtn(){
	$('#searchResultsBtn').removeAttr('disabled');
	if (!$('#searchResultsBtn').is(':disabled')) {
		$('#searchResultsBtn').css('background-color','#005eb8'); 
    }
}

function populateFacets(data){
	if(data != null && data != undefined){
		$(".more").show();
		$(".fewer").hide();
		for(i=0; i < data.length; i++){
			if(data[i] != null){
				if(data[i].dim=='ifg'){
					$('#businessFacets .count').html(data[i].value);
					$('#businessFacets .body').html(createFacetHtml('ifg',data[i]));
					if(data[i].labelValues.length<=5){
						$("#businessFacets").parent().find(".more").hide();
					}
				}else
				if(data[i].dim=='business'){
					$('#businessSegmentFacets .count').html(data[i].value);
					$('#businessSegmentFacets .body').html(createFacetHtml('business',data[i]));
					if(data[i].labelValues.length<=5){
						$("#businessSegmentFacets").parent().find(".more").hide();
					}
				}else
				if(data[i].dim=='subBusiness'){
					$('#subBusinessFacets .count').html(data[i].value);
					$('#subBusinessFacets .body').html(createFacetHtml('subBusiness',data[i]));
					if(data[i].labelValues.length<=5){
						$("#subBusinessFacets").parent().find(".more").hide();
					}
				}else
				if(data[i].dim=='jobFunction'){
					$('#functionFacets .count').html(data[i].value);
					$('#functionFacets .body').html(createFacetHtml('function',data[i]));
					if(data[i].labelValues.length<=5){
						$("#functionFacets").parent().find(".more").hide();
					}
				}else
				if(data[i].dim=='country'){
					$('#countryFacets .count').html(data[i].value);
					$('#countryFacets .body').html(createFacetHtml('country',data[i]));
					if(data[i].labelValues.length<=5){
						$("#countryFacets").parent().find(".more").hide();
					}
				}else
				if(data[i].dim=='band'){
					$('#bandFacets .count').html(data[i].value);
					$('#bandFacets .body').html(createFacetHtml('band',data[i]));
					if(data[i].labelValues.length<=5){
						$("#bandFacets").parent().find(".more").hide();
					}
				}
			}
		}
		$(".facet").find(".facetList:gt(4)").hide();
	}
}

function createFacetHtml(param,data){
	var html = "";
	for(k=0; k < data.labelValues.length; k++){
		html = html + '<div class="facetList">';
		html = html + '<input type="checkbox" name="'+param+'" value="' + data.labelValues[k].label+ '">';
		html = html + '<span class="text">'+ wrapLabel(data.labelValues[k].label) +'</span>';
		html = html + '<span style="float: right;">'+data.labelValues[k].value+'</span></div>';
	}
	return html;
}
	
function initFacetSearch(){
	if(!facetInitialized){
		facetParameters = getSearchParameters("facetSearch");
		setFacetParameters(facetParameters);
		facetInitialized = true;
	}
}

function setFacetParameters(params){
	  
	   if(params!=null){

		   if(hasValue(params.ifg)){
			   setCheckBox($('input:checkbox[name=ifg]'), params.ifg);
		   }	
		   
		   if(hasValue(params.business)){			 
			   setCheckBox($('input:checkbox[name=business]'), params.business);
		   }
		   
		   if(hasValue(params.subBusiness)){			 
			   setCheckBox($('input:checkbox[name=subBusiness]'), params.subBusiness);
		   }
		   
		   if(hasValue(params["function"])){
			   setCheckBox($('input:checkbox[name=function]'), params["function"]);
		   }	  

		   if(hasValue(params.country)){
			   setCheckBox($('input:checkbox[name=country]'), params.country);
		   }
		   
		   if(bandVisibility && hasValue(params.band)){
			   setCheckBox($('input:checkbox[name=band]'), params.band);
		   }
		   	  
	   }
	   
}

function setCheckBox(input, checkBoxValues){
	var isClearFac = false;
	for(var cc = 0; cc < checkBoxValues.length; cc++){
	   input.each(function(index, value){
		   value = $(value);
		   if(value.val() == UTF8.decode(checkBoxValues[cc])){				   
			   value.prop("checked",true);			   
			   isClearFac = true;
		   }
	   });  
	}
	if(isClearFac){
		input.closest(".facet").find(".clearFacets").show();	
	}
}

function wrapLabel(label){
	if(label.length > 30){
		label = label.substr(0, 28);
		label = label + "...";
	}
	return label;
}
UTF8 = {
	    encode: function(s){
	        for(var c, i = -1, l = (s = s.split("")).length, o = String.fromCharCode; ++i < l;
	            s[i] = (c = s[i].charCodeAt(0)) >= 127 ? o(0xc0 | (c >>> 6)) + o(0x80 | (c & 0x3f)) : s[i]
	        );
	        return s.join("");
	    },
	    decode: function(s){
	        for(var a, b, i = -1, l = (s = s.split("")).length, o = String.fromCharCode, c = "charCodeAt"; ++i < l;
	            ((a = s[i][c](0)) & 0x80) &&
	            (s[i] = (a & 0xfc) == 0xc0 && ((b = s[i + 1][c](0)) & 0xc0) == 0x80 ?
	            o(((a & 0x03) << 6) + (b & 0x3f)) : o(128), s[++i] = "")
	        );
	        return s.join("");
	    }
	};
	
	