$('#myholder1').hide();
var topHierData1 = null;
var topHierData2 = null;
var topHierLoaded = false;
var paper1;
var graph1;
var paper;
var graph;
var sso;
var currentSSO = 0;
var previousSSO = 0;
var topsso = 213004520;
var myscale = 0.59;
if (currentSSO != 0) {
    previousSSO = currentSSO;
}
currentSSO = sso;
console.log("previousSSO: " + previousSSO);
console.log("currentSSO: " + currentSSO);

function slider(val) {
    var x = 0.39 + val / 100;
    myscale = x;
    paper.scale(myscale, myscale);
    paper.fitToContent({
        padding: 100
    });
}

//function that displays slider status
function displayFunction() {
    var x = document.getElementById("range").value;
    document.getElementById("sliderStatus").innerHTML = x;
}

//function for zoom out
function zoomout() {
    myscale = myscale - 0.1;
	var y = (myscale - 0.39) * 100;
	if(y >= 0 && y <= 40){
    paper.scale(myscale, myscale);
    paper.fitToContent({
        padding: 100
    });
    
    document.getElementById("range").value = y;
    displayFunction();
	}
}

//function for zoom in
function zoomin() {
    myscale = myscale + 0.1;
	var y = (myscale - 0.39) * 100;
	if(y >= 0 && y <= 40){
    paper.scale(myscale, myscale);
    paper.fitToContent({
        padding: 100
    });
    
    document.getElementById("range").value = y;
    displayFunction();
	}
}

//function for default 
function zoomdefault() {
    myscale = 0.50;
    paper.scale(myscale, myscale);
    paper.fitToContent({
        padding: 100
    });
	paper1.scale(myscale, myscale);
    paper1.fitToContent({
        padding: 100
    });
    var y = (myscale - 0.39) * 100;
    document.getElementById("range").value = y;
    displayFunction();
}

graph = new joint.dia.Graph;
graph1 = new joint.dia.Graph;
var ClickableView = joint.dia.ElementView.extend({
    pointerdown: function() {
        this._click = true;
        joint.dia.ElementView.prototype.pointerdown.apply(this, arguments);
        
    },
    pointermove: function() {
        this._click = false;
        joint.dia.ElementView.prototype.pointermove.apply(this, arguments);
    },
    pointerup: function(evt, x, y) {
        if (this._click) {
            // triggers an event on the paper and the element itself
            this.notify('cell:click', evt, x, y);

        } else {
            joint.dia.ElementView.prototype.pointerup.apply(this, arguments);
        }
    }
});
paper = new joint.dia.Paper({
    //labeling the 'el' is how we are able to reference this in the html (line 50)
    el: $('#myholder'),
    width: 1200,
    height: 1000,
    gridSize: 1,
    //defining the model of paper points it to the graph variable which will have the cells
    model: graph,
    perpendicularLinks: true,
    interactive: false,
    elementView: ClickableView
});
//set default scale for paper
paper.scale(myscale, myscale);

// implement dragging  
var w = document.getElementById("myholder");
var mouseDownFlag = false;
var lastx = 0;
var lasty = 0;
var newx = 0;
var newy = 0;
var wh = 0;
var at = 0;

paper.on('blank:pointerdown', function(evt, x, y) {
	 evt.css('cursor', 'pointer');
    mouseDownFlag = true;
    lastx = evt.clientX;
    lasty = evt.clientY;
});



document.body.onmousemove = function(me1) {
    newx = me1.clientX;
    newy = me1.clientY;

    if (mouseDownFlag == true) {
        w.scrollLeft = w.scrollLeft + (lastx - newx);
        w.scrollTop = w.scrollTop + (lasty - newy);
        lastx = newx;
        lasty = newy;
    }

};
document.body.onmouseup = function(me2) {
    mouseDownFlag = false;
};

function trim(message, maxLength) {
    var m = message;
    var maxLen = maxLength;
    if (m && m.length > maxLen) {
        var lastSpace = m.lastIndexOf(' ');
        //there is no space in the word
        if (lastSpace === -1) {
            m = m.slice(0, maxLen - 3);
            m += '...';
        } else if (lastSpace > -1) {
            m = m.slice(0, maxLen - 3);
            var t = m.lastIndexOf(' ');
            m = m.slice(0, t);
            m += '...';
        }
    }
    return m;
}
var member = function(x, y, name, rank, image, background, border, sso, city, imageUrl,contingent, topsso) {

    //cell width = 180, cell height = 70
    var rel = ((topsso == true) ? 'toppers' : 'null');
	var cws = ((contingent==true) ? 'cw' : 'ncw');
    cell = new joint.shapes.org.Member({
        position: {
            x: x,
            y: y
        },
        size: ((topsso == true) ?{ width: 300, height:85 }: { width: 227, height: 85 }), 
        attrs: {
            '.card': {
                fill: '#F0F1F2',
			   'xlink:rel':cws
            },
            '.image': {
                'xlink:href': 'http://executivecareerbrand.com/wp-content/uploads/2015/07/No_person.jpg'
            }, //background no-photo image behind every member-image
            '.pic': {
                'xlink:href': '../../images/person/temp/' + sso + '.jpg',
                rel
			
            },
			'.anchor1': { 'xlink:href': 'https://employeeprofile.ge.com/employeeprofile/people/' + sso, 'xlink:show': 'new', cursor: 'pointer'},
            '.anchor1 .name': {
                text: trim(name, 20)
            },
			'.anchor2': ((topsso==true)?{ 'xlink:href': 'https://employeeprofile.ge.com/employeeprofile/sso/' + sso, 'xlink:show': 'new', cursor: 'pointer'}:''),
			'.anchor2 .name': ((topsso==true)?{
              text: 'View employee profile',
			  'font-size': 12
            }:''),
			/*'.anchor3': ((topsso==true)?{  text: 'View reporting line':''),*/
			'.anchor3 .name': ((topsso==true)?{
              text: 'View reporting line',
			  'font-size':9
            }:''),

			 '.anchor4':((topsso==false)? { 'xlink:href': 'https://employeeprofile.ge.com/employeeprofile/people/' + sso, 'xlink:show': 'new', cursor: 'pointer'}:''),
			'.anchor4 .name':((topsso==false)? {
               text: 'Go to Employee Profile'
           }:''),
			'.anchor5': ((topsso==false)?{ 'xlink:href': 'https://employeeprofile.ge.com/employeeprofile/people/' + sso, 'xlink:show': 'new', cursor: 'pointer'}:''),
           '.anchor5 .name': ((topsso==false)? {
               text: 'View Org Chart'
           }:''),
            '.rank': {
                text: trim(rank, 20) + "\n" + trim(city, 23)
            },
            '.sso': {
               text:((contingent==true)?'(\n\n\n CW )':'')
            }
		
        }

    });

    graph.addCell(cell);
    return cell;
};
var memberOne = function(x, y, name, rank, image, background, border, sso, city, imageUrl,contingent ,topsso) {
    //cell width = 180, cell height = 70

    cell = new joint.shapes.org.Member({
        position: {
            x: x,
            y: y
        },
        attrs: {
            '.card': {
                fill: '#F0F1F2'
            },
            '.image': {
                'xlink:href': 'http://executivecareerbrand.com/wp-content/uploads/2015/07/No_person.jpg'
            }, 
            '.pic': {
                'xlink:href': '../../images/person/temp/' + sso + '.jpg'
            },
            a: {
                'xlink:href': 'https://employeeprofile.ge.com/employeeprofile/people/' + sso,
                'xlink:show': 'new',
                cursor: 'pointer'
            },
            '.anchor1': { 'xlink:href': 'https://employeeprofile.ge.com/employeeprofile/people/' + sso, 'xlink:show': 'new', cursor: 'pointer'},
            '.anchor1 .name': {
                text: trim(name, 20)
            },
            '.rank': {
                text: trim(rank, 26) + "\n" + trim(city, 23)
            },
            '.sso': {
                text: sso
            }
        }

    });

    graph1.addCell(cell);
    return cell;
};

function link(source, target, breakpoints) {
    var cell = new joint.shapes.org.Arrow({
        source: {
            id: source.id
        },
        target: {
            id: target.id
        },
        vertices: breakpoints
    });
    graph.addCell(cell);
    return cell;
}

function link2(source, target, breakpoints) {
    var cell = new joint.shapes.org.Arrow({
        source: {
            id: source.id
        },
        target: {
            id: target.id
        },
        vertices: breakpoints
    });
    graph1.addCell(cell);
    return cell;
}
var global_startingX = 778; //from LEFT of page
var global_startingY = 87; //from TOP of page
var global_xOffset = 255; //HORIZONTAL spacing
var global_yOffset = 110; //VERTICAL spacing
var mult = 0;
var tmp1 = new joint.shapes.org.Member();
var cardWidth = tmp1["_previousAttributes"].size["width"];
var subOffset = global_xOffset - cardWidth - 10;
var horizMult = 2;
var i = 0;
var j = 0;
var employees = [];
var manager = new Object();
var manager1 = new Object();
var manager2 = new Object();
var contingent=false;

$.ajax({
    dataType: "json",
    url: '../../data/213004520/employee.json',
    success: function(data) {
        topHierData2 = data.manager;
        topHierData1 = data.lowerManager;
		topsso=true;
        manager = member(global_startingX, global_startingY, data.name, data.role, data.sso, '#F1C40F', 'gray', data.sso, data.city, data.imageUrl,contingent,topsso);
        sso = data.sso;
        var contingent=false;
		topsso=false;
        $.each(data.directReportlist.list, function(idx, obj) {
            var horizMult = 2;

            if (i == 0) {
                employees[i] = member(global_startingX, global_startingY + global_yOffset, obj.name, obj.role, obj.sso, '#F1C40F', 'gray', obj.sso, obj.city, obj.imageUrl,contingent,topsso);
                link(manager, employees[i], [{
                    x: global_startingX + 170,
                    y: 185
                }]);
                console.log("emp--" + employees[i].sso);
                if (obj.contingentWorkerlist != "undefined" && obj.contingentWorkerlist) {
			      contingent=true;
                    $.each(obj.contingentWorkerlist.list, function(idx1, obj1) {
                        if (i == 0) {
                            employees[i][j] = member(global_startingX + subOffset, global_startingY + horizMult * global_yOffset, obj1.name, obj1.role, obj1.sso, '#F1C40F', 'gray', obj1.sso, obj1.city, obj1.imageUrl , contingent,topsso);
                            link(employees[i], employees[i][j], [{
                                x: global_startingX,
                                y: 135 + horizMult * global_yOffset
                            }]);
                        }
                        horizMult += 1;
                        j += 1;
                    });
                }
                if (!obj.contingentWorkerlist) {
				  contingent=false;
                    $.each(obj.directReportlist.list, function(idx1, obj1) {
                        if (i == 0) {
                            employees[i][j] = member(global_startingX + subOffset, global_startingY + horizMult * global_yOffset, obj1.name, obj1.role, obj1.sso, '#F1C40F', 'gray', obj1.sso, obj1.city, obj1.imageUrl,contingent ,topsso);
                            link(employees[i], employees[i][j], [{
                                x: global_startingX,
                                y: 135 + horizMult * global_yOffset
                            }]);
                        }
                        horizMult += 1;
                        j += 1;
                    });
                }
                mult += 1;
            } else if (i % 2 == 0) {
			contingent=false;
                employees[i] = member(global_startingX - (mult * global_xOffset), global_startingY + global_yOffset, obj.name, obj.role, obj.sso, '#F1C40F', 'gray', obj.sso, obj.sso, obj.city, obj.imageUrl, contingent ,topsso);
                link(employees[0], employees[i], [{
                    x: global_startingX +170,
                    y: 185
                }, {
                    x: global_startingX + (-1 * mult * global_xOffset) + 70,
                    y: 185
                }]);
                if (obj.contingentWorkerlist != "undefined" && obj.contingentWorkerlist) {
				contingent=true;
                    $.each(obj.contingentWorkerlist.list, function(idx, obj1) {
                        if (i % 2 == 0) {
                            employees[i][j] = member(global_startingX - (mult * global_xOffset) + subOffset, global_startingY + horizMult * global_yOffset, obj1.name, obj1.role, obj1.sso, '#F1C40F', 'gray', obj1.sso, obj1.city, obj1.imageUrl,contingent,topsso);
                            link(employees[i], employees[i][j], [{
                                x: global_startingX - (mult * global_xOffset),
                                y: 135 + horizMult * global_yOffset
                            }]);
                            horizMult += 1;
                        }
                        j += 1;
                    });
                }
                if (!obj.contingentWorkerlist) {
				      contingent=false;
                    $.each(obj.directReportlist.list, function(idx, obj1) {
                        if (i % 2 == 0) {
                            employees[i][j] = member(global_startingX - (mult * global_xOffset) + subOffset, global_startingY + horizMult * global_yOffset, obj1.name, obj1.role, obj1.sso, '#F1C40F', 'gray', obj1.sso, obj1.city, obj1.imageUrl, contingent ,topsso);
                            link(employees[i], employees[i][j], [{
                                x: global_startingX - (mult * global_xOffset),
                                y: 135 + horizMult * global_yOffset
                            }]);
                            horizMult += 1;
                        }
                        j += 1;
                    });
                }
                mult += 1;
            } else {
			contingent=false;
                employees[i] = member(global_startingX + (mult * global_xOffset), global_startingY + global_yOffset, obj.name, obj.role, obj.sso, '#F1C40F', 'gray', obj.sso, obj.city, obj.imageUrl ,contingent ,topsso);
                link(employees[0], employees[i], [{
                    x: global_startingX + 170,
                    y: 185
                }, {
                    x: (global_startingX + (mult * global_xOffset) + 70),
                    y: 185
                }]);
                if (obj.contingentWorkerlist != "undefined" && obj.contingentWorkerlist) {
				contingent=true;
                    $.each(obj.contingentWorkerlist.list, function(idx, obj1) {
                        console.log('level3===>' + obj1.name);
                        employees[i][j] = member(global_startingX + (mult * global_xOffset) + subOffset, global_startingY + horizMult * global_yOffset, obj1.name, obj1.role, obj1.sso, '#F1C40F', 'gray', obj1.sso, obj1.city, obj1.imageUrl,contingent ,topsso);
                        link(employees[i], employees[i][j], [{
                            x: global_startingX + (mult * global_xOffset),
                            y: 135 + horizMult * global_yOffset
                        }]);
                        horizMult += 1;
                        j += 1;
                    });
                }
                if (!obj.contingentWorkerlist) {
				contingent=false;
                    $.each(obj.directReportlist.list, function(idx, obj1) {
                        console.log('level3===>' + obj1.name);
                        employees[i][j] = member(global_startingX + (mult * global_xOffset) + subOffset, global_startingY + horizMult * global_yOffset, obj1.name, obj1.role, obj1.sso, '#F1C40F', 'gray', obj1.sso, obj1.city, obj1.imageUrl ,contingent ,topsso);
                        link(employees[i], employees[i][j], [{
                            x: global_startingX + (mult * global_xOffset),
                            y: 135 + horizMult * global_yOffset
                        }]);
                        horizMult += 1;
                        j += 1;
                    });
                }
            }
            j += 1;
            i += 1;
        });

        function link(source, target, breakpoints) {

            var cell = new joint.shapes.org.Arrow({
                source: {
                    id: source.id
                },
                target: {
                    id: target.id
                },
                vertices: breakpoints
            });
            graph.addCell(cell);
  
            jQuery('.anchor4').hide();
            jQuery('.anchor5').hide();
     
            return cell;
        }
    }


});
var renderManager = function() {
    $('#myholder1').toggle();
	
	
	//function for slider	
	function slider(val) {
    var x = 0.39 + val / 100;
    myscale = x;
	paper1.scale(myscale, myscale);
    paper1.fitToContent({
        padding: 100
    });
}

//function for zoom out
function zoomout() {
    myscale = myscale - 0.1;
	var y = (myscale - 0.39) * 100;
	if(y >= 0 && y <= 40){
	paper1.scale(myscale, myscale);
	 paper1.fitToContent({
        padding: 100
    });
    
    document.getElementById("range").value = y;
    displayFunction();
	}
}


//function for zoom in
function zoomin() {
    myscale = myscale + 0.1;
	 var y = (myscale - 0.39) * 100;
	 if(y >= 0 && y <= 40){
	 paper1.scale(myscale, myscale);
    paper1.fitToContent({
        padding: 100
    });
   
    document.getElementById("range").value = y;
    displayFunction();
	}
}

//function that displays slider status
function displayFunction() {
    var x = document.getElementById("range").value;
    document.getElementById("sliderStatus").innerHTML = x;
}
	
    if (!topHierLoaded) {
        topHierLoaded = true;
        var tmp1 = new joint.shapes.org.Member();
        var cardWidth = tmp1["_previousAttributes"].size["width"];
        paper1 = new joint.dia.Paper({
            //labeling the 'el' is how we are able to reference this in the html (line 50)
            el: $('#myholder1'),
            width: 1200,
            height: 300,
            gridSize: 1,
            //defining the model of paper points it to the graph variable which will have the cells
            model: graph1,
            perpendicularLinks: true,
            interactive: false
        });
        paper1.scale(myscale, myscale);

        paper1.on('blank:pointerdown', function(evt, x, y) {
            mouseDownFlag = true;
            lastx = evt.clientX;
            lasty = evt.clientY;
        });
		//paper1.$el.on('mousewheel DOMMouseScroll', onMouseWheel);
		topsso=false;
        manager1 = memberOne(778, 0, topHierData2.name, topHierData2.role, topHierData2.sso, '#F1C40F', 'gray', topHierData2.sso, topHierData2.city, topHierData2.imageUrl,contingent,topsso);
        manager2 = memberOne(778, 97, topHierData1.name, topHierData1.role, topHierData1.sso, '#F1C40F', 'gray', topHierData1.sso, topHierData1.city, topHierData1.imageUrl,contingent,topsso);
        link2(manager1, manager2, [{
            x: 850,
            y: 185
        }]);

    }
};

var cuurrCell;
paper.on('cell:mouseover', //highlights the card on hovered
    function(cellView, evt, x, y) {	    
	
		   cellView.highlight();
		    
        function shows(){
            var tprl = $('#' + cellView.id  + ' .pic').attr('rel');
            if (tprl != 'toppers') {
	          $('#' + cellView.id + ' .pic').hide();
	    	  $('#' + cellView.id + ' .image').hide();
	    	  $('#' + cellView.id + ' .rank').hide();
	    	  $('#' + cellView.id + ' .anchor1').hide();	
	          $('#' + cellView.id + ' .anchor4').show();
	    	  $('#' + cellView.id + ' .anchor5').show();
           }
    }	
 
    shows();

    });


  

paper.on('cell:mouseout', //unhighlights card when mouse moves out of area
    function(cellView, evt, x, y) {
	$('#' + cellView.id + ' .pic').show();
	$('#' + cellView.id + ' .image').show();
	$('#' + cellView.id + ' .rank').show();
	$('#' + cellView.id + ' .anchor1').show();
    $('#' + cellView.id + ' .anchor4').hide();
    $('#' + cellView.id + ' .anchor5').hide(); 
    $('#' + cellView.id + ' .name').show(); 

        cellView.unhighlight();
    });

paper.on('cell:click', function(element) {

    var tprl = $('#' + element.id + ' .pic').attr('rel');
    if (tprl == 'toppers') {
   
    if($('#' + element.id +' .anchor3 text').text()=="View reporting line"){
    $('#' + element.id +' .anchor3 text').text("Hide reporting line");
    }else if( $('#' + element.id +' .anchor3 text').text()=="Hide reporting line"){
       $('#' + element.id +' .anchor3 text').text("View reporting line");
       }
        renderManager();

    }
});

$("#continngentWorker").click(function(){
	
var c=[];
jQuery('.card').each(function() {
 var currentElement = $(this);
if(currentElement.attr('rel')=="cw")
{
var i=currentElement.attr('id');
 $('#'+i).parent().parent().parent().toggle();
}
});
 $('#'+c).parent().parent().parent().toggle();
  

});

