require.config({
  shim: {
	'components/bootstrap/js/bootstrap.min': ['jquery'],
    'ge-bootstrap/accordion.min': ['jquery']
  }
});
define([
    'jquery',
    'components/bootstrap/js/bootstrap.min',
    'ge-bootstrap/accordion.min'
  ], function($) {
    'use strict';
    return $;
  }
);
