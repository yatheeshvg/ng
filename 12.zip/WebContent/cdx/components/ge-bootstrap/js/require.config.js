requirejs.config({
  baseUrl: "./",
  paths: {
    "ge-bootstrap": "js/ge-bootstrap",
    bootstrap: "components/bootstrap/docs/assets/js/bootstrap",
    brandkit: "components/brandkit/js/brandkit",
    "font-awesome": "components/font-awesome",
    jquery: "components/jquery/jquery",
    prettify: "components/prettify/prettify"
  }
});
