/*! JointJS v0.9.3 - JavaScript diagramming library  2015-02-03 


This Source Code Form is subject to the terms of the Mozilla Public
License, v. 2.0. If a copy of the MPL was not distributed with this
file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
if (typeof exports === 'object') {

    var joint = {
        util: require('../src/core').util,
        shapes: {},
        dia: {
            Element: require('../src/joint.dia.element').Element,
            Link: require('../src/joint.dia.link').Link
        }
    };
}

joint.shapes.org = {};

joint.shapes.org.Member = joint.dia.Element.extend({

 //   markup: '<g class="rotatable"><g class="scalable"><rect class="card"/><a class="anchor3"><text class="name"/></a><image class="image"/><image class="pic"/></g><a class="anchor1"><text class="name"/></a><a class="anchor2"><text class="name"/></a><text class="rank"/><text style="display: none;" class="sso"/></g>',
	  markup: '<g class="rotatable"><g class="scalable"><rect class="card"/><a class="anchor3"><text class="name"/></a><image class="image"/><image class="pic"/></g><a class="anchor5"><text class="name"/></a><a class="anchor1"><text class="name"/></a><a class="anchor2"><text class="name"/></a><a class="anchor4"><text class="name"/></a><text class="rank"/><text style="display: none;" class="sso"/></g>',  
	defaults: joint.util.deepSupplement({

        type: 'org.Member',
        size: { width: 227, height: 95 },
        attrs: {

            rect: { width: 170, height: 60 },

            '.card': {
                fill: '#FFFFFF', stroke: '#F0F1F2', 'stroke-width': 0,
                'pointer-events': 'visiblePainted', rx: 0, ry: 0
            },
            
            '.image': {
		        width: 30, height: 50,
                ref: '.card', 'ref-x': 0.52, 'ref-y': 0.05
            },

            '.pic': {
		        width: 50, height: 50,
                ref: '.card', 'ref-x': 0.48, 'ref-y': 0.05
            },
			
            '.anchor1 .name': {
                'font-weight': '600', fill: '#005CB9',
                ref: '.card', 'ref-x': 0.05, 'ref-y': 0.1, 
                'font-family': 'GEInspRg', 'font-size': 13,
				'text-anchor': 'start'
            },
			
            '.anchor2 .name': {
                'font-weight': '600', fill: '#005CB9',
                ref: '.card', 'ref-x': 0.05, 'ref-y': 0.8, 
                'font-family': 'GEInspRg', 'font-size': 13,
				'text-anchor': 'start'
            },
			  '.anchor3 .name': {
                'font-weight': '600', fill: '#005CB9',
                pic: '.card', 'ref-x': 100, 'ref-y': 1, 
                'font-family': 'GEInspRg', 'font-size': 9,
				'text-anchor': 'start','display':'block','padding-left':'30px','right':0,
            },
            '.anchor4 .name': {
                'font-weight': '600', fill: '#005CB9',
                pic: '.card', 'ref-x': 0.05, 'ref-y': 0.50, 
               'font-family': 'GEInspRg', 'font-size': 13,
				'text-anchor': 'start'
            },
            '.anchor5 .name': {
                'font-weight': '600', fill: '#005CB9',
                ref: '.card', 'ref-x': 0.05, 'ref-y': 0.20, 
                'font-family': 'GEInspRg', 'font-size': 13,
				'text-anchor': 'start'
            },
            
            '.rank': {
                fill: '#666666',
                ref: '.card', 'ref-x': 0.05, 'ref-y': 0.35, 
                'font-family': 'GEInspRg', 'font-size': 12,
		        'text-anchor': 'start'
            },
            '.test': {
                'font-weight': '800',
                ref: '.card', 'ref-x': 0.9, 'ref-y': 0.6,
                'font-family': 'Arial', 'font-size': 16,
                'text-anchor': 'end'
            }
        },
        get_height: function(){
            return size;
        }  

    }, joint.dia.Element.prototype.defaults)
});

joint.shapes.org.Arrow = joint.dia.Link.extend({

    defaults: {
        type: 'org.Arrow',
        source: { selector: '.card' }, 
        target: { selector: '.card' }, 
        attrs: { '.connection': { stroke: '#CCCCCC', 'stroke-width': 1 }},
        z: -1
    }
});


if (typeof exports === 'object') {

    module.exports = joint.shapes.org;
}
