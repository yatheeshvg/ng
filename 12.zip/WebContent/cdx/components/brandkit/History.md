2.3.1 / 2014-1-22
==================
* GESans 1.0 and GESerif 1.0 web fonts
* GE Inspira Bold Italic was broken previously
* Separated fonts.less from main brandkit.less file so that we can compile without fonts (for Typekit)
* Removed Meta Serif font

2.0.2 / 2013-11-05
==================
* GESans 1.0 and GESerif 1.0

2.0.1 / 2013-11-05
==================
* GE Brand Refresh

0.3.0 / 2013-07-05
==================
* Include @inputDisabledText
